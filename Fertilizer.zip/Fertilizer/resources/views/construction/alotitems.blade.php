@extends('layouts.master')

@section('title', 'Accounts System-Project Items')

@section('content')
<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('project/createitem') }}">Create Project Item</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">View Project Items</a>
  </li>

</ul><br>

    <h3>Project Items</h3>
    <a href="{{ url('project/createitem') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Create Project Item</a>
    <hr>
     <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            <th>SNo.</th>
            <th>Item</th>
            <th>Project</th>
            <th>User</th>
            <th>Date</th>
            
            </tr>
        </thead>
        <tbody>
            @foreach($aloteditems as $item)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $item->itemdescription }}</td>
                <td>{{ $item->projectname }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ date('d-m-Y', strtotime($item->created_at))}}</td>
               
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Item</th>
            <th>Project</th>
            <th>User</th>
            <th>Date</th>
            </tr>
        </tfoot>
    </table>
@stop
