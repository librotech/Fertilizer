@extends('layouts.master')

@section('title', 'Accounts System-Project')

@section('content')
<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('project/view') }}">View Projects</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Update Project</a>
  </li>

</ul><br>
    <h3>Update Project</h3>
    <a href="{{ url('project/view') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Projects</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger alert-dismissible fade in">{{ $error }}</p>
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('project/update') }}" method="post">
        {{ csrf_field() }}
        <div class="row">
            @foreach($projects as $project)
            @php
            $total = $project->total
            @endphp
            <input type="hidden" name="project_id" value="{{ $project->id }}">
            <div class="col-md-3">
                <div class="form-group">
                <label>Project Name</label>
                <input type="text"  required="required" name="p_name" class="form-control" value="{{ $project->projectname }}" placeholder="Enter Project Name">
            </div>
            </div>
            <div class="col-md-3">
               <div class="form-group">
                <label>Date</label>
                <input type="text" required="required" name="date" class="form-control" placeholder="Enter Date" value="{{ $project->date }}" id="datepicker" readonly="">
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Assign To</label>
                <select name="emp" class="form-control" required="">
                    <option value="{{ $project->employee_id }}">{{ $project->name }}</option>
                    @foreach($employees as $employee)
                    <option value="{{ $employee->id }}">{{ $employee->name }}</option>
                    @endforeach

                </select>
            </div>
            </div>
            @endforeach
        </div>
        <table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Date</th>
                </tr>
                </thead>
                <tbody>
                 @foreach($projectdetails as $projectdetail)    
                <tr>
                    <td>
                    <input type="hidden" name="pdid[]" value="{{ $projectdetail->id }}">
                    <input type="text" required="required"  name="description[]" class="form-control" value="{{ $projectdetail->description }}" autocomplete="no" placeholder="Description">
                    </td>

                    <td><input type="number"  id="amount" min="0"  name="amount[]" class="form-control amount" value="{{ $projectdetail->amount }}"  placeholder="Amount"></td>

                    <td><input type="text" required="required" name="rowdate[]" class="form-control a" placeholder="Enter Date" data-id="{{ $projectdetail->id }}" value="{{ $projectdetail->date }}" id="datepicker{{ $projectdetail->id }}" readonly=""></td>

                     <td><!-- <button type="button" class="btn btn-success" id="add_more">+</button> --></td>

                </tr>
                @endforeach
            </tbody>

        </table>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>Total</label>
                    <input type="text" readonly="" value="{{ $total }}" name="total" id="total" class="form-control">
                </div></div>
        </div>
        <div class="row">
        <div class="col-md-9"></div>
        <div class="col-md-3">
        <button class="btn  btn-success btn-block">Update</button></div></div>
        </div>
    </form>
    
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
    
    // var count=1;
    // $(document).on('click','#add_more',function(){
    //     $('.order-list').append('<tr id="row'+count+'"><td><input type="text" required="required"  name="description[]" class="form-control"  autocomplete="no" placeholder="Description"></td><td><input type="number"  id="amount" min="0"  name="amount[]" class="form-control amount"  placeholder="Amount"></td><td><input type="text" required="required" name="rowdate[]" class="form-control a" placeholder="Enter Date" value="" id="#aa'+count+'" data-id="'+count+'" readonly=""></td><td><button type="button" class="btn btn-danger remove" data-id="'+count+'">×</button></td></tr>');
    //          // $( ".a").datepicker({ dateFormat: "yy-mm-dd"});
    //     count++;
    // });
    
    // $(document).on('click','.remove',function(){
    //     var id=$(this).attr('data-id');
    //     $('#row'+id).remove();
    // });

    $(document).on('change','.amount',function(){
        var total = 0;
        $('.amount').each(function() {
            total +=parseInt($(this).val());
        });
        $('#total').val(total);
    })
    $(document).ready(function(){
        $('.a').on('click', function() {
          var id=$(this).attr('data-id'); 
        $('#datepicker'+id).datepicker({dateFormat: "yy-mm-dd"}).focus();
        });
    });
</script>