@extends('layouts.master')

@section('title', 'Accounts System-Project Items')

@section('content')
<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('project/view') }}">View Projects</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Alot Project Item</a>
  </li>

</ul><br>
    <h3>Alot Item</h3>
    <a href="{{ url('project/viewaloteditems') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Items</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    <form action="{{ url('alot/item') }}" method="post">
    	{{ csrf_field() }}
        <table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Item</th>
                    <th>Project</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                     <input type="text" data-id="1" required="required"  name="item1" class="form-control item item1" placeholder="Item" autocomplete="no" list="items">
                    <datalist class="items" id="items">
                        @foreach($items as $item)
                        <option value="{{ $item->id }}">{{ $item->itemdescription }}</option>
                        @endforeach
                    </datalist>
                    </td>

                    <td> 
                    <input type="text" data-id="1" required="required"  name="project1" class="form-control project project1" placeholder="project" autocomplete="no" list="project">
                    <datalist class="project" id="project">
                        @foreach($projects as $project)
                        <option value="{{ $project->id }}">{{ $project->projectname }}</option>
                        @endforeach
                    </datalist></td>

                    

                     <td><button type="button" class="btn btn-success" id="add_more">+</button></td>

                </tr>
            </tbody>
        </table>
        <div class="row">
        <div class="col-md-9"></div>
        <div class="col-md-3">
        <button class="btn  btn-success btn-block">Save</button></div></div>
        
    </form>
    
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
    
    var count=1;
    $(document).on('click','#add_more',function(){
        $('.order-list').append('<tr id="row'+count+'"><td><input type="text" data-id="1" required="required"  name="item[]" class="form-control item item1" placeholder="item Id" autocomplete="no" list="items"><datalist class="items" id="items">@foreach($items as $item)<option value="{{ $item->id }}">{{ $item->itemdescription }}</option>@endforeach</datalist></td><td><input type="text" data-id="1" required="required"  name="project[]" class="form-control project project1" placeholder="item Id" autocomplete="no" list="project"><datalist class="project" id="project">@foreach($projects as $project)<option value="{{ $project->id }}">{{ $project->projectname }}</option>@endforeach</datalist></td><td><button type="button" class="btn btn-danger remove" data-id="'+count+'">×</button></td></tr>');
        count++;
    });
    $(document).on('click','.remove',function(){
        var id=$(this).attr('data-id');
        $('#row'+id).remove();
    });

    $(document).on('change','.amount',function(){
        var total = 0;
        $('.amount').each(function() {
            total +=parseInt($(this).val());
        });
        $('#total').val(total);
    })
    
</script>