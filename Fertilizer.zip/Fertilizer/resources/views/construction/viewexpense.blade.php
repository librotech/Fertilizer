@extends('layouts.master')

@section('title', 'Accounts System-Project Expense')

@section('content')
<ul class="nav nav-tabs">
 <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Expenses</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('pexpense/add') }}">Add Project Expense</a>
  </li>
  
</ul><br>
    <h3>All Expenses</h3> <a href="{{ url('pexpense/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add Project Expense</a>
    <hr>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
           <th>SNo.</th>
            <th>Expense Id</th>
            <th>Project Name</th>
            <th>Status</th>
            <th>Date</th>
            <th>Total</th>
            <th>Date</th>
            <th>Delete</th>
            <th>Approve</th>
        </tr>
        </thead>
        <tbody>
            

        @foreach($pexpenses as $pexpense)
            
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $pexpense->id }}</td>
                <td>{{ $pexpense->projectname }}</td>
                <td>
                @if($pexpense->approve == 1)
                <p class='text text-success'>{{ 'Approved' }}</p>
                @elseif($pexpense->approve == 0)
                <p class='text text-danger'>{{ 'Unapproved' }}</p>
                @endif
                </td>
                <td>{{ $pexpense->date }}</td>
                <td>{{ $pexpense->total }}</td>
                <td>{{ $pexpense->created_at }}</td>
                <td><a href="{{ url('pexpense/delete/'.$pexpense->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                <td><a href="{{ url('pexpense/show/'.$pexpense->id)}}" class="btn btn-success btn-sm">Approve</a></td>
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
             <th>SNo.</th>
            <th>Expense Id</th>
            <th>Project Name</th>
            <th>Status</th>
            <th>Date</th>
            <th>Total</th>
            <th>Date</th>
            <th>Delete</th>
            <th>Approve</th>
            </tr>
        </tfoot>
    </table> 
   

    
@stop
