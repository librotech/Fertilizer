@extends('layouts.master')

@section('title', 'Accounts System-Home')
<style type="text/css">
	.canvasjs-chart-credit{
		display:none;
	}
	
</style>
<script type="text/javascript" src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script> 
<script type="text/javascript" src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script> 
<script type="text/javascript"> 
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Monthly Sales"
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.00\"\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: <?php echo ($credit_sales) ?>, label: "Credit Sales"},
			{y: <?php echo ($cash_sales) ?>, label: "Cash Sales"}
			//,
			// {y: 7.06, label: "Baidu"},
			// {y: 4.91, label: "Yahoo"},
			// {y: 1.26, label: "Others"}
		]
	}]
});
chart.render();


var chart = new CanvasJS.Chart("barchart",
    {
      title:{
		text: "Annual Bussiness Progress"
	},
	axisX: {
		title: "Months"
	},
	legend: {
		cursor:"pointer",
		itemclick : toggleDataSeries
	},
	toolTip: {
		shared: true,
		content: toolTipFormatter
	},
      data: [
      {
      	name: "Sales",
		color: "#84A7D0",
        showInLegend: true,
        dataPoints: [
			{ y: <?php echo $jansaleincome; ?>, label: "January" },
			{ y: <?php echo $fabsaleincome; ?>, label: "February" },
			{ y: <?php echo $marchsaleincome; ?>, label: "March" },
			{ y: <?php echo $aprilsaleincome; ?>, label: "April" },
			{ y: <?php echo $maysaleincome; ?>, label: "May" },
			{ y: <?php echo $junsaleincome; ?>, label: "June" },
			{ y: <?php echo $julysaleincome; ?>, label: "July" },
			{ y: <?php echo $augsaleincome; ?>, label: "Octuber" },
			{ y: <?php echo $sepsaleincome; ?>, label: "September" },
			{ y: <?php echo $octsaleincome; ?>, label: "Octuber" },
			{ y: <?php echo $novsaleincome; ?>, label: "November" },
			{ y: <?php echo $decsaleincome; ?>, label: "Descember" }
		]
      },

      {
      	name: "Cost Of Sales",
		color: "#D38583",
        showInLegend: true,
        dataPoints: [
			{ y: <?php if(isset($janexpense)){echo $janexpense->balance;}else{ echo 0 ;} ?>, label: "January" },
			{ y: <?php if(isset($fabexpense)){echo $fabexpense->balance;}else{ echo 0 ;} ?>, label: "February" },
			{ y: <?php if(isset($marchexpense)){echo $marchexpense->balance;}else{ echo 0 ;} ?>, label: "March" },

			{ y: <?php if(isset($aprilexpense)){echo $aprilexpense->balance;}else{ echo 0 ;} ?>, label: "April" },
			{ y: <?php if(isset($mayexpense)){echo $mayexpense->balance;}else{ echo 0 ;} ?>, label: "May" },
			{ y: <?php if(isset($junexpense)){echo $junexpense->balance;}else{ echo 0 ;} ?>, label: "June" },

			{ y: <?php if(isset($julyexpense)){echo $julyexpense->balance;}else{ echo 0 ;} ?>, label: "July" },
			{ y: <?php if(isset($augexpense)){echo $augexpense->balance;}else{ echo 0 ;} ?>, label: "August" },
			{ y: <?php if(isset($sepexpense)){echo $sepexpense->balance;}else{ echo 0 ;} ?>, label: "September" },

			{ y: <?php if(isset($octexpense)){echo $octexpense->balance;}else{ echo 0 ;} ?>, label: "Octuber" },
			{ y: <?php if(isset($novexpense)){echo $novexpense->balance;}else{ echo 0 ;} ?>, label: "November" },
			{ y: <?php if(isset($decexpense)){echo $decexpense->balance;}else{ echo 0 ;} ?>, label: "Descember" }
		]
      }

      ]

    });

chart.render();
	function toolTipFormatter(e) {
		var str = "";
		var total = 0 ;
		var str3;
		var str2 ;
		for (var i = 0; i < e.entries.length; i++){
			var str1 = "<span style= \"color:"+e.entries[i].dataSeries.color + "\">" + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong> <br/>" ;
			total = (e.entries[0].dataPoint.y - e.entries[1].dataPoint.y);
			str = str.concat(str1);
		}
		str2 = "<strong>" + e.entries[0].dataPoint.label + "</strong> <br/>";
		str3 = "<span style = \"color:Tomato\">Total: </span><strong>" + total + "</strong><br/>";
		return (str2.concat(str)).concat(str3);
	}

	function toggleDataSeries(e) {
		if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
			e.dataSeries.visible = false;
		}
		else {
			e.dataSeries.visible = true;
		}
		chart.render();
	}
}

</script> 
@section('content')
    <h3>Business Insights</h3>
    <hr>
    <div class="row">
    	<div class="col-md-4" >
    	<div style="background:#FEE9A8;height:150px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.3em;">Cash In Hand</h5>
		    <b>{{ number_format(round($total_cashinhand)) }}</b>
		    <h5 class="card-text" style="font-size: 1.3em;">Other Assets</h5>
		    <b>{{ number_format($total_oaccblnc) }}</b>
		</div>
    	</div>
    	
    	<div class="col-md-4" >
    	<div style="background:#B2DBF9;height:150px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Amount Payable</h5>
		    <b>{{ number_format(round($totalpayable)) }}</b>
		</div>
    	</div>
    	
    	<div class="col-md-4" >
    	<div style="background:#B1BFC7;height:150px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Amount Recievable</h5>
		    @php $customertotal=0; @endphp
		    @foreach($assets as $asset)
			@if($asset->balance > 0)
			@if(strpos($asset->account_id, 'customer_') !== false)
            			<?php
            $customertotal += $asset->balance;
            ?>
            @endif
            @endif
		@endforeach
		    <b>{{ number_format(round($customertotal)) }}</b>
		</div>
    	</div>
    	<div class="col-md-12"><hr></div>
    	<div class="col-md-4" >
    	<div style="background:#F0F1F3;height:110px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Revenue</h5>
		    <b>{{ number_format(round($revenue)) }}</b>
		</div>
    	</div>
    	<div class="col-md-4" >
    	<div style="background:#F0F1F3;height:110px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Expense</h5>
		    <b>{{ number_format(round($total_expenses)) }}</b>
		</div>
    	</div>
    	<div class="col-md-4" >
    	<div style="background:#F0F1F3;height:110px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Profit</h5>
		    <b>{{ number_format(round($revenue)-round($total_expenses)-round($totalcos)) }}</b>
		</div>
    	</div>

    	<div class="col-md-12"><hr></div>

    	
    	<div class="col-md-4" >
    	<div style="background:#FEE9A8;height:150px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.3em;">Sales Target</h5>
		    <b>0</b>
		    <h5 class="card-text" style="font-size: 1.3em;">Achieved</h5>
		    <b>0</b>
		</div>
    	</div>
    	
    	<div class="col-md-4" >
    	<div style="background:#FEE9A8;height:150px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Top 3 Fertilizer</h5>
		   
		    
		</div>
    	</div>
    	<div class="col-md-4" >
    	<div style="background:#B2DBF9;height:150px;padding:15px;">
		    <h5 class="card-text" style="font-size: 1.5em;">Notifications</h5>
		    <h5><a href="notification" class="text text-success">{{ $notification }} New Notifications</a></h5>
		</div>	
    	</div>
    	<div class="col-md-12"><hr></div>
    	<div class="col-md-12">
    	<br>
    	<div id="chartContainer" style=" width: 100%; height: 300px"></div>
    	<br>
    	<div id="barchart" style="height: 300px; width: 100%;"></div>
    	<br>
    	</div>
    </div>
    
@stop
