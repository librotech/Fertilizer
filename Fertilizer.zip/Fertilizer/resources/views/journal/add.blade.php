@extends('layouts.master')

@section('title', 'Accounts System-Journal Enteries')

@section('content')
<ul class="nav nav-tabs">
<li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('journal/show') }}">View Journal Entries</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Add New Journal Entries</a>
  </li>
</ul><br>
    <h3>New Journal Entries</h3>
    <a href="{{ url('journal/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Journal Entries</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('journal/save') }}" id="myForm" method="post">

    	<div class="row">
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Journal No</label>
                @foreach($auto_increment as $ai)
    			<input type="number" name="txt_inv_no" value="{{ $ai->AUTO_INCREMENT }}" class="form-control" readonly="readonly">
                @endforeach
    		</div>
    		
    	</div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text" id="datepicker" readonly="readonly" value="<?php echo "20".date('y-m-d', time()); ?>" style="background:white !important;" name="txt_date" class="form-control">
            </div>
        </div>
    	</div>
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Account Code</th>
    				<th>Account Name</th>
    				<th>Account Type</th>
    				<th>Description</th>
    				<th>Debit</th>
    				<th>Credit</th>
                    <th>Add More</th>
    			</tr>
    			</thead>
    			<tbody>
    			<tr>
    			 <td>
                    <input type="text" required="required" data-id="1"  name="coa_id1" class="form-control coa_id" placeholder="Chart of Account id"  list="coas" autocomplete="off">
                    <datalist id="coas">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->coa_id }}">{{ $chartofaccount->coa_title }}</option>
                    @endforeach
                    </datalist>
                    </td>
    				<td><input type="text"  readonly="readonly" name="coa_name" class="form-control coa_name1"  placeholder="Account Name"></td>

    				<td><input type="text"  readonly="readonly"  name="coa_type1" class="form-control coa_type1" placeholder="Account Type"></td>
    				<td><input type="text" required="required"  name="description1" class="form-control" placeholder="description" ></td>
                    <td><input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="debit1" class="form-control debit debit1"  data-id="1"placeholder="Debit Amount"></td>
                    <td><input type="number" required="required"  name="credit1" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" data-id="1" class="form-control credit credit1" placeholder="Credit Amount"></td>
                    
    				<td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

    			</tr>
    		</tbody>

    	</table>
        <div class="row">
             <div class="col-md-9"></div>
            <div class="col-md-3">
                <label><b>Balance</b></label><input type="number" name="balance" readonly="readonly" id="balance" class="form-control"><br>
            </div>
        </div>
        <div class="row">
             <div class="col-md-9"></div>
            <div class="col-md-3"><button class="btn btn-block btn-success" id="save">save</button></div>
        </div>
        {{ csrf_field() }}
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function () {
    var counter = 1;
    
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text"  autocomplete="off" data-id="'+counter+'"  name="coa_id[]" class="form-control coa_id" placeholder="Chart of Account id" list="coas"><datalist id="coas"></datalist>';
        cols +='<td><input type="text"  readonly="readonly" name="coa_name" class="form-control coa_name'+counter+'" placeholder="Account Name"></td>';
        cols +='<td><input type="text"  readonly="readonly"  name="coa_type[]" class="form-control coa_type'+counter+'" placeholder="Account Type"></td>';
        cols += '<td><input type="text"   name="description[]" class="form-control" placeholder="description"></td>';
        cols += '<td><input type="number"  min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57"  name="debit[]" data-id="'+counter+'" class="form-control debit debit'+counter+'" placeholder="Debit Amount"></td>';
         cols += '<td><input type="number"  min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="credit[]" data-id="'+counter+'" class="form-control credit credit'+counter+'" placeholder="Credit Amount"></td><input type="hidden" name="counter[]" value="'+counter+'">';

        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });

    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
    });

    var formProcessing = false;
    jQuery("#myForm").on("submit", function(e) {
        
        e.preventDefault();
        
        if( formProcessing )
            return;

        formProcessing = true;
        jQuery("#myForm").get(0).submit();
        
    });

});
    
$(document).on('change', '.coa_id', function(){
 var _token = $('input[name="_token"]').val();
    var coa=this.value;
    var coa_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
            dataType: 'json',
          url: '{{ url("journal/coas") }}',
          data: { coa:coa,_token:_token },
          success: function(data){
            $('.coa_name'+coa_id).val(data[0]);
            $('.coa_type'+coa_id).val(data[1]);
         }
      });
});

$(document).on('keyup', '.debit', function(){
    var debit_id=$(this).attr('data-id');
    $('.credit'+debit_id).prop("readonly", true);
});
$(document).on('keyup', '.debit', function(){
if(!$(this).val()){
        var debit_id=$(this).attr('data-id');
        $('.credit'+debit_id).prop("readonly", false);
    }
});
$(document).on('keyup', '.credit', function(){

    var credit_id=$(this).attr('data-id');
    
    $('.debit'+credit_id).prop("readonly", true);

});
$(document).on('keyup', '.credit', function(){
if(!$(this).val()){
       var credit_id=$(this).attr('data-id');
    $('.debit'+credit_id).prop("readonly", false);
    }
});

$(document).on('keyup', '.debit,.credit', function(){
var debittotal = 0;
var credittotal=0;
$('.debit').each(function(){
      var inputval=$(this).val();
      if(inputval > 0){
      debittotal += parseInt(inputval, 10);
     }
    });
    $('.credit').each(function(){
      var inputval=$(this).val();
      if(inputval > 0){
      credittotal += parseInt(inputval, 10);
      }
      });
    $('#balance').val(parseInt(credittotal-debittotal));
    if($('#balance').val() != 0){
        $('#save').hide();
    }
    else if($('#balance').val() == 0){
        $('#save').show();
    }
});

</script>