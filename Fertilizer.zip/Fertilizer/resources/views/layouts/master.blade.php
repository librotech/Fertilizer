@include('layouts.header')
<div class="container-fluid">
  
  <div class="row">
    <div class="se-pre-con col-md-12">
   
    </div>
    <div class="col-md-2" style="background:#385793;border-top:1px solid white;border-bottom:1px solid white;min-height:1100px">
      <div class="card" style="border:none;margin-left:-15px;">
        <div class="card-header"><i class="fas fa-tachometer-alt" style="color:white;"></i>&nbsp<a  href="{{ url('/home') }}">Dashboard</a></div>
         <div class="card-header"><i class="fas fa-hand-holding-usd" style="color:white;"></i>&nbsp <a href="{{ url('sale/add') }}">Sale</a></div>
        <div class="card-header"><i class="fas fa-shopping-cart" style="color:white;"></i>&nbsp<a href="{{ url('purchase/add') }}">Purchase</a></div>
        <div class="card-header"><i class="fas fa-donate" style="color:white;"></i>&nbsp<a href="{{ url('expense/add') }}">Record Expense</a></div>
        @if(Auth::user()->role != 3)
        <div class="card-header"><i class="fas fa-chart-bar" style="color:white;"></i>&nbsp<a href="{{ url('coa/show') }}">Chart Of Account</a></div>
        @endif
         <div class="card-header"><i class="fas fa-calculator" style="color:white;"></i>&nbsp<a href="{{ url('journal/add') }}">Journal Entries</a></div>
        
        @if(Auth::user()->role != 3)
        
          <div class="card-header"><i class="fas fa-hand-holding-usd" style="color:white;"></i>&nbsp <a href="{{ url('employees/returnsaleview') }}">Return Sale</a></div>
        <div class="card-header"><i class="fas fa-hand-holding-usd" style="color:white;"></i>&nbsp <a href="{{ url('purchase/payment') }}">Cash Paid</a></div>
        <div class="card-header"><i class="fas fa-hand-holding-usd" style="color:white;"></i>&nbsp <a href="{{ url('sale/payment') }}">Cash Received</a></div>
        <div class="card-header"><i class="fas fa-exchange-alt" style="color:white;"></i>&nbsp<a href="{{ url('fundstranser/add') }}">Funds Transfer</a></div>
        
        <!--<div class="card-header"><i class="fas fa-exchange-alt" style="color:white;"></i>&nbsp-->
        <!--  <a href="{{ url('employee/alotmachine') }}" >Alot Machine</a></div>-->
          
       <!--  <div class="card-header"><i class="fas fa-credit-card" style="color:white;"></i>&nbsp<a  href="{{ url('creditnotes/add') }}">Sales Return</a></div>
         <div class="card-header"><i class="fas fa-credit-card" style="color:white;"></i>&nbsp<a  href="{{ url('debitnotes/add') }} ">Purchase Return</a></div>-->
        @endif
      </div>
      </div>
    <div class="col-md-10"  id="forms">
      <hr>
      @yield('content')
    </div>
  <script type="text/javascript">
        $(document).ready(function() {

      $('#example').DataTable( {

        dom: 'Blfrtip',
         <?php if(Request::url() == url('ledger/show')){ ?>
        order: [
          [5,'desc']
        ],
      <?php } ?>
        columnDefs: [{
        targets: -1,
        className: 'dt-body-right'
        }],
        buttons: [
            'colvis',
            {
              extend:'print',
              exportOptions: {
              columns: ':visible',
              modifier: {
                    page: 'current'
                }},
                customize: function ( win ) {
                  $(win.document.body)
                        .css( 'font-size', '10pt' )
                        .prepend(
                            '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                        );
                    $(win.document.body).find('table').css('text-align', 'center');
                    $(win.document.body).find('table').css('font-size', '20px' );
                    $(win.document.body).find('table  tr th').css('border', '1px solid');
                    $(win.document.body).find('table  tr td').css('border', '1px solid');
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .css( {
                        border:'1px solid',
                        width:'100%',
                        alignment:'center',
                    } );
                    

                }

            },
            {
              extend:'excelHtml5',
              exportOptions: {
              columns: ':visible',
              modifier: {
                    page: 'current'
                }},
            },
            {
              extend:'csvHtml5',
              exportOptions: {
              columns: ':visible',
              modifier: {
                    page: 'current'
                }},
            },
            {
              extend:'pdfHtml5',
              pageSize: 'LEGAL',
              exportOptions: {
              columns: ':visible',
              modifier: {
                    page: 'current',
                    alignment: 'center',
                }},
            customize: function ( doc ) {
              var tblBody = doc.content[1].table.body;
              $('#example').find('thead tr').each(function (ix, row) {
                    var index = ix;
                    var rowElt = row;
                    $(row).find('th').each(function (ind, elt) {
                        tblBody[index][ind].border
                       tblBody[index][ind].fillColor = '#AAACB0';
                      
                    });

                });
              $('#example').find('tr').each(function (ix, row) {
                    var index = ix;
                    var rowElt = row;
                    $(row).find('td').each(function (ind, elt) {
                        tblBody[index][ind].border
                       tblBody[index][ind].fillColor = 'white';
                    });
                });
              var colCount = new Array();
              $('#example').find('tbody tr:first-child td').each(function(){
                  if($(this).attr('colspan')){
                      for(var i=1;i<=$(this).attr('colspan');$i++){

                          colCount.push('*');
                      }
                  }else{ colCount.push('*'); }
              });
              doc.content[1].table.widths = colCount;
              doc.styles.title = {
                fontSize: '20px',
                alignment: 'center'
              }
              doc.styles= {
              color: 'none',                   
              alignment: 'center',
              border:'1px solid'}

             doc.content.splice(1, 0,
              {
                  alignment: 'left',
                  image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHMAAABOCAYAAAATpymVAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAC4jAAAuIwF4pT92AAAX6UlEQVR42u2bCXgURdrHa3IPJOQgJARISBhAdFdcXHVF8ENEhXHdKCieyCFyKSGAIiCgKIdKXDk8EEUQFTmCkBjkJoAHigEhIEeABAIMVwhHIJBhktT+3563YzGbmVyKfm7X8/ye7q6761/11ls9iRBGMIIRjGAEIxjBCEYwghGMYAQjGMEIRjCCEYxgBCMYwQhGMMKvFrLv0vAB/nyv48X8v3gBIhx0Aa35hf4XhSSeBv8GvoqQL4A+ep4/UodNjPoC3uAdUArywL/+UB2/umL2ArtBDD83ADtBwh9mTJTVNw7MArcoL1AbfAskM/J/QUxl5fkpYxEFfgLd+fkhsF0X94/UcZp1JSzYBlCP4wPAWo6n1dlNeTlK6wz6gYZ/JpH5XW4FyeB2fV8Ec8B8YAap4GMlrRaPR8vfbSy44fvABRaNRB2vbPirOd4B4pVZ+xy4yGlzdefgTyRmU/AF2A/eAnH7O4gbc+4Wd1/qYQrJvlt0wXNLXr13gUXgqLJyf7eO+7GZvczinAe9QRjYooj5AOd/HJxWzG8GCK3OC8j+JsILXA/+VQ4dQV3Od7X3yQD2E7bR+MghptpygGkC+vEDri/JMSZ/doCO8RZ1m26af++ZSPvjDEWgoyzoAX4moR8F/cFJJV+2InJ1xbwBHATFwAEuMw6OmwG8r5aY5YjaYPftIgLtdwF2IMFFCNpxb3vxF6R31L3c36uDZEY6gWjF7jfkVaYL9SaYxDNvJTtAF5V08u7a1MSssJhNwffgjDZIzsEqBQXgFHiNV+/VtFQWdgZ7gMQdrUUQ2n9AEbMQ3LO2ibYd3cL5/a+qieXGGoFNbDr3gJm84kiYAWAfeWrYHzrYe5ssZx4RXYCFzatuig/zXlGjzuvmE0SCv4B3lMHqAa4Bta6WmeX3uYUn6l72YJdif4yRiTCz/U1jwCrwgnze5I/4a5CeCbLYv3jvqnm43NlWIF9ZYbq3Wgg2ooMd87ua/ooOTwE54DjY5HjalACBR7PD04lNiz/vLaE8O0NqaHJHsZjnwW26gIroZuDH9/4gDrQCTZR4dS/+G0gAr4CBXGdtJY8PaFA2YZ4zeec9KBoe7Cji990proUZDWFP1VTaV8vfEFhBeOGTJgHz64t814A7MW4vIt/s/K6iPUzwfcjzIGjhukVwuybuP/XFt1qTVdnYX2VPrUA5lmhAsMHozOs8qCrnEf9E1h2acOPZ9K7i4wvNYBvNYl75v4WY5CQtBx+Ah0AyyGXzfAjMYpOtDxatbJvLOxRwuRjO1x3s57L9Oe0bvGcqSAARivA0WT7lvfxNpAkQDl4AI+Qzplal/U2JSNvDeUrAEfCSMoFoMt4FJvMK/w4s5r7Wqq6gPjzodJ7qiVk1BxzK7iB2Hrtf0EDtLEdMiU6vPWTVzqWXXVa2TjHo+huJmchp5BRdUvpVrNyT2CGgJQsseR8m0fN5L6b8j3Gdn3GeEpd69LjVoBnnDQYZnLaUJ8x9yj5K+3uRsk2c43tK78yrdD6/m+vYUp5xbCmquWc9i04mmgJL+po6XehmeuH0w6ID7qNRYZYbMbOO36+JdZTFs/PqLuCz6lbw199IzKEu/SGxxrJjslYZlHjwPD8XsXmNZnM8jMvU5zrnKfWR0JsAHT9S2KOWvFppZZET9CPHLeOBr8crS+3XRj5W3QnW8VjSRNyitEPe+wLwFtisTIZ/VEtMfhla2h/yS9NA7NNMCJma8sSEacDKbcYfDWiPsIJ/sNPQmr3j32rPHKL04yAPlp7WR0kbzLNcX5UPuO5Jyp6qikkCNuI0Eu4TpY57eax+4LgVyh6ttp2qmHAiDFjAXGWyTePtwJvz3K+s7r41EZMcnZPlmJeicoTMxab/DIRaz2dN+pzV+Ndyx6tgZiWvUtXZ6aqYSRL9HsWcHWZnjlZLhIuDpIt5jE2zWmcbcJbT3+TV+T0/r2QHRhWziJ0j4dLv68BRzvOF4p0HgjvYZEu2BA/VREyaRXvdrEKpNLIQJvkG9mKLlD1yM8fV+OexSoiZwGkXwO0uaY/yJJQ8uF7seBS47EtbwdMshEkRM4dNsVonHZd2KaY2mB0WyXupq5iX2Llxfaf72SGS2pHGmWciW79zSv8WgdCaiEn0A6c9iFnKDsSkc4+b2kK0BS4fD+jT3nQ+mtT0A0JlxKS01i5pj3E/Kb2n4n12AFPZPBYog/6My55ZkZjkuNQB3/LzGhBQSTG7cd+IE8qHEXVsx3N71T9Pc2FvPhPlV7BCia8Lu5uaw/PtrHy31ZnDv4H+3mL2YOckSDmm1OG9U/dwf+Rvvp+7iqnQSTHV41k83ZdI52NGZcS0umxblC8bLOF3av6rfOFSOt5N2YQron9RLxOtwCZgIR9HSMxPyxOz+delotm6y0RAs3WOFiCu2XqHF/gtxCxlB2gmD/w9yjuSqB/r+z9/cJhbjph0iG+rHENo32zHZnUDx62rgpixfJbV9++u/KHCR1lM9D4vc39NNTG15HF9XUkhieeoHJvUEP5Ncyxo7mpmLasuEr6W1ZfaN11TlNx0rf14s3T7fnA3QNtegmf8k2TGFTNGE2s2HxPuKEdMV6Ef5j2zhAdFP1od4Lrrc5kdHE/HgXBlZZ5nod9ir/ak4gxOZoFJvPUcv0FxZCoS08QOlP5eZPavZX+FJsm7Snsb2YpUe1X2VM5UruzljdnGZngpfzrzWHfc8vOi2eoLuBY0bbLi/DtNVhaetqwqlBBWWlYTlz6yLDtruvRsLWr/pgpM/HpeFc8qDlAbFzEfVLzZXqA3fxnSB5mOXHn87GCP1/Wc6Uoef+QPUb7epOvbjSLm0+7EVPrXWFkwJbx3HuR30dsjj3dQtUwuNxLOs6G8lylmR8GXv4Jcr88aT401/vI0yA+ITTvTPW7p2d1xX52TccuIAglxZZPl5yUEXg0C1r18j24ZprCn6MpaFkfwufIIr6pYFzFb8+w+w06P4K8za12+uJxjCxDo4s0W8qRZzs7OKJ5kPi5HmfdYjJlK2r1cno43fyuFtWm6vlg0WXHBG/g0XusQjgRfIftpYziH+1minGF38sq9oSZCCp7BDjdifstiV6rOxil5ImbJSSIqJiVvRuPUUxcbp+ZLCCtjvzwtY9OIMzJ2KXE2AwQD1QnDOU4E8kDrBOh7COe5VhfSRUwfPq60d/ngXof3vz5spm9X0tVz5gHtcN8PE7c74vu6rK46oA/oKcJlb9Ee13ras7OeAD7Dtj88JMan8Vfnro376uxoTOJksAT3U8GjkSsuRchewo8XRWe09bB8WrRFXISMFSbZrmaOT5iyR5X3rfDJqrjK0YuOiUY9PqDrlOgvjsvoxSdkDLHkpJOUPI3GKackhM4CUaDazhsmClkAL1z9YQ1MZBGq8RcOVxxNto24keq8FUwA96Fub60dEJt6KqJR2tme9ZcWDo1KO9/aknJcS6MQg7bbrjpLZTtj0mY7J+4VODChM5B+pyU1TwSuLBbm1aUBqKtXdNrZiYi/ISbtjNDrq86qfNSDB5uu7xWVDY2Sj4pGC46IRgttTwAbkIhzsuiYjCZIZKfQR0BTwKv5hBeuD8UsyZuBa2dMAnp22xZbgCDkn4AJshr33WIWH/eK+uyAiJyzz1x/zr7OoAfu60V+vM8bxOC+NbgdNKs754C/fESY+FcQp5h9RCP/5TIM9W3iiXcUtEIb1FYI7pNBKaedQHznmDJrpF1b4fmAPmlBCShWnolVyGvWyqXkPQAucvwylK/l6Z0r+ia71I2QRcqvClWqu+H8w6Jx8gnRYF7uGw3mHZIN5xOHnSw4oqGJvNB2CiK3pAkAcYkW4BCLnQuaU7xbK+As0wlc4jJ7QIOoz3JE5OysJyNn770ESnG/KGJ21kxcc8B5cAEcQdz8sNn7W1/u73srOyY58inRMCS1MA71HOE67cBaTls6acCPLFLDuQcpzzQl7RQm5PPgYUzYj7nOAty/ge3Im+tMVPJngjBP7+xJzHbKd8fyvMeQ6px16n+yn4iJ+jRnOwZWYqXIqLnEQdngcyJXQmhw6By4GThXdPLRto2SbRcAVrLtHJ5vpniPViD5aHfkLeUyh/AcW//THBHx0e5J9T7aLXUi9PuZjB43c5ctaFZOVzgsTTRz21tEBy8piENdNq7TDqyA2orHBLzM8U4W2lYiPgBXskahiNuipL8dvTjPi4QGvuAaWKebcQ3UtiOtTluikj8ThFF8dUzsVDdCOpTPYVUSMmLWHqzMQ7QyRkd+vFfCtEmYOrBfQmCQLet/mu2A0BA55wiEvpbMIq1m0A5c5FV8FtxE8Z4sAOhbturnH84B0WhXhH/wcxKQLlwE34OVIE+JtwV/sKeN7CvaYGVGhibnN0E9Nq7TDqxaWwuOROK61mlpNM7juVdDTEbuSww4wOVKwKMUX/+jPZ76n6j0PxOEeXpnd2JG86/h5Yn5fVU8WDXU+3An0QIzfn8Ez34I7GR2loTIlyHwKxC3B8S1QlgfCCywaon24CKtYJAPbqB4d4HLPMv5ib0gCitP1J2emQSkQl7d97f3C5+xow7ww30nxB1U0hf3mzCxjiTLMjfXgnpsXKcdWKktWBQiFgwDSeCfsDB+QO9LLMjlcg4QX4n+Jyr9zwRhnsq4W5WPuDmOFPNH9yqvyrrvbRMh0zZ7hb+//U0MmNTAzK9HfLjTycxdGyBwXeBimrOJO8ElbfV+kn0CXEfx7s25VmYI5yd2ggi0K8Le+SkJSKYg7N2tverN2GGq++5WQYRO20x5EkAJ5zkN/oH+Up0WYOM67cBKbWESErUxERMwEd+CxbkhClsKWSPuSyzI5XIOEO/afzhehJfmlM3Z1wDpY5X+74qcs78l4qMZM+VvMPdAhWJOd7Mqt/M3wyoLicEgbsXAHQcScU702f/+9gsY6C4QW0DgK18SphHcA4qc5nnvMXANxbsLXGYE5ye2glC0LUKmZiQByXyDSRYIysqGTssg4pCWo+QbQO+BOizAxnXagVVra7bGQxwHK7M3LXJWVgCsjd6XWJDL5RygS+SHO70hdi1QG/hGzaE6sh5H2R3gIMhX+m/H8yGOB1lzI2Zl1YdF8yhmsPJruSvjqrMqQ6ZsEsGTN5kxIPMwSBIzX4a+TWyRYQTN/ne3LoCoZhqw/9prsVJBR2Bn83wUNHNdwWXmfOYuvczYMnP+0e6NIDB0aoYIfuuHJCCZdGAGZeWDJ/9AUNxaJd8EmpCowwJsXCf1x8ptEYOU9jJAMCamF/rzMFiE50JOK8XzFrASrAcbwRzQAmkpSh2eKNLb9iRms3L+Yk3y75lV/vuTOknfYfC+F8H/3vgQroXawEz+QYZM3iQhMvgRs/7HkxC4DQ10qLJC9EDmDXQEReyUHAXNwl1WcFl+mFIuM0lxZMix8ae+1HnzuyQgmXRgBr/0Gffotx+uK5R8E2nFog4LOUVcpx1YuS1ioNLeZhAEWij5K2I4tpsuuG4BB0C+kkZt5XJ8TviHO+cgb33yQzyJeZubvw7boP/+V5UQ9MbXRGTQpG82BiV9K+to6AO0UUJkzPrvp4ZMy/DG6i3fTE/PJDqAS2yWj4HmFO/OrMNsU5npihMzHybcC/2g/iQByaQDM/VTD4Gvf01EIW6nki+BJgLqsQAb12kHVu4f8YzS3k8gGP1oiOt3oNTF6XJw+SJQoOV/f3t7qgeTMQxE4f5lJf8u9P96xDcCDUEATdoQWAtPYlrdfPV5vaomtvaEdHhkuaL2xHUjA19bXwpk4OsbNMoGadI3eyFyC+C2Ht5v24IL7JCcBNeFuXkRiocJN+H6ueLoTINJp74QSUAy6cBM8Xqfaw9bTHkSgIPzFNSeuP7/aMWiHguwcZ12YOX+Ef2V9raCUIrH5IrBNjIA9/mcVgzGIu5uAum3ggjazwnlnROV+jJBmLt3didmx3LELGYPt9JCmsetFrVeXS3Mr67+e61xaw4BWWv8WlmbmJDuZOK6Ygg8iPJCYLd1sUNyIzjj3HMzToNWFF9ufjLXUzP8kL6c8xMjKD/6QCRRX5h0YKZ4EhL9rYu+JuL5pJJnJdKCaGWiDguwcZ12YOX+Ef2U9raBMCUtFuRymgPEu+u/8s6JSn2Zen1VEbOl8rseI86uG9jSKkYse8x3REqQ7/CUCuvyf2mZ8B+zLCjg5RWLAsaukOaxK6X5FWKVxIDJWsS4NSswUKE0kJ4COyTXgGO034JC0I7iPeQPARmcvwQ8RvFon0jS+uHkKPo2GYwF08FmxF12pml9Pob7DlSO67UAG9drB1aOJ/pwPLEd1FXSYkEupzlAvLv+K++QqNSXCcI8lSlPzEDlD4Z1MQ8NSuzzqGlYis1n2OKn/EakCu/nv3Bbj9/IL4Xo/6nwG5U2xH/0V5eBhLAaAS8td/Ly8hMBY1e2g9DaAHt0ot7cSETBzGWxM1ICHlGdlivzf0fEgVzOXwBuo3i0TSSV9cMzOehnV0w+EyalXq8F2LheO7ByPNFbcZh2gHAlLVbpjwPEu+u/8g6JSn2ZIMxTGXfnzF5X/mWByH4scfBjYuii815Dkw97DV3Yye+puQLX/6rD54XFwhdi+w5f0hHX40D6jkyVEFj6vZjmZFRaCQQebR6/xgSBK3aiyGmZ9E2toDe+WQckMybojW/LNc9II+4AhZw3G8RQvN+opUQSkG4oAtn+o5e+iz629HuZLMxXar0WYON67cDK8UQvpX8/g3pKWizI5TQHiKd4946jViZRqS8ThHkq407QOlf+Sb042Htgv8dF4oKzpsR50jR4vg3XZ0EwEIJAIHH9hmPVPpfcxvv5Rbu8h30hsZIlBAZLpM/wJRImWsJUfwVxw7QVXIlAggWOTxfYX9/WnCgnadjH/HXHRXW6yDNF+hgl74rA1zYE4OqcaCNSk7RJ5mQP+jEUJICnwD1+L34Zg6s3rlf2A+WBBdi4XjuwcjzRU2lzJ6inpMWCXE5zgHiKd/vOzjIJSn2ZIMxTGU+r89pf/vdB5L/1zL1PioR5NpEwVzJ2sA4kgjvALWLQ51aI+yrEPuA1ZIH0GrJQQmCQLCEwWCQh8j6fYV+0AsLHg6m+wpmCI8WOyyPAwU7Jaey5Vs1pGbeGna41ojblG7fmVqTvVxwYWAGKXy0wuYgkbZI5SQdmiq8ocB8swMb12oGV44nuSpu7QYSSFgtyOY3eId6Tr8BlBir1ZYK6FfkXngT9u/PvaUTxtgGxA0XC/C2KmDql4CI4xwJLiFqGtpI15tOKPguRHzYN+lx4D02uUp/MTs+4EfbXnxXnZT8clqex78ZhTwvDtTGeeyM+S8lzEtxE+zImlE6Sc3JppAMzxVfYB6fzZAE2rtsOrBxPdAOlnLYHRCppsSCX0xwg3pOvwGUGKO+xA4RX5F9UJCj9Z/KXjv7e75gSPvukHDErSxEY4TV4vjeJWdVghqOEPUxAtP5wTC4qTsplcAhsAwf4WU8rhgPzRsArK33I0cJk0kkCkkkHZoqvKLDzZAG2svpfWt6v+Qc2Pe0JUMppWaA+xxOxIJfTHCCe4itoq7/yLjtBPU9lKitoKFZn66CEmd3KVl/VoDKvATOo9t/0kLME/CHqc3BQTuhOi79CWdzopaeQbxzy19EdGEGTyEmSYj3SgVlUYoKhTiIa9e9X2jsOh+5udqy6Iq6Y43fjGgkEE4O4A1zuMu7/SWXcngicZXriWsr1ZaLtutSHmgcSIWFuEBgOskBJJYUk8zsG1KqJkGUv+WIaQc7JLXBSpsBT3gyOgnxgAxkUj/TWyOdD+V3egUhS+pde2UlGDpE/tQ2HCe3klTlRI1MHAjqSNcV1EygAk5HXl8qQo+c3Ms2MuI+BnfqMOIsnB9BZRqsvHRzB/Sh/53uLXyc4B8IEGoN+IAUc5D2z1GUfJRHXgy7A99cQ8ooj0PAUHINSTPCOQ0Fz0BI0BSHwnE0+5X3YqKGYFOiDie/wVG945u3QzmwwBW01wLMwwYlCeiNwIwjUPq4Mmi+8nfFEGGgH4jiv+/d7YYnwh6DIU5fyA7/KfKyprqiEH4gDHUBPMJi9W3i+c1uD4LK8f4TwS79HK2KmVHWy0XGMPprAO/eC4+QFD10Y4fcTtBmYB1byRPzjTDgjVNuqBBhCGsEIRjCCEYxgBCMYwQhGMIIRjGAEIxjBCEYwghGMYAQj/JnCfwATUqqIYnA8TQAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAASdEVYdEVYSUY6T3JpZW50YXRpb24AMYRY7O8AAAAASUVORK5CYII=',
              }

             );
            }
            }
        ]
          
    } );       
        } );
  </script>

  <script src="{{ url('/assets/js/popper.min.js') }}" ></script>
  <script src="{{ url('/assets/js/bootstrap.min.js') }}" ></script>
  <script src="{{ url('/assets/js/jquery.dataTables.min.js') }}"></script>
  <script src="{{ url('/assets/js/dataTables.bootstrap4.min.js') }}"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>
 
    <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

  </div>
</div>
<nav class="navbar navbar-light bg-faded" style="background:#385793 !important;height:60px;color:white;border-top:white;width:">
  <span>&copy; Copyright 2018 Inspire Uplift</span><span style="float:right;">Contact :+923********</span>
</nav>

</body>

</html>