@extends('layouts.master')

@section('title', 'Accounts System-Inventory')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">All Inventories</a>
  </li>
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <div class="row"><div class="col-md-8"><h3>All Inventories</h3></div><div class="col-md-4"><input type="text" class="form-control" id="search"  name="search" placeholder="Search By Product Id or Supplier id">{{ csrf_field() }}</div></div>
    <hr>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Sno.</th>
            <th>Product</th>
            <th>Qty</th>
        </tr>
        </thead>
        <tbody>
        @foreach($inventories as $inventorie)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td><a href="{{ url('single-product-inventory/show/'.$inventorie->inv_product_id) }}">{{ $inventorie->product_description  }}</a></td>
            <td>{{  $inventorie->sum }}</td>
        </tr>
        @endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>Sno.</th>
            <th>Product</th>
            <th>Qty</th>
            
            </tr>
        </tfoot>
    </table>
 
@stop
