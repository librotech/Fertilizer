@extends('layouts.master')

@section('title', 'Accounts System-Customers')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Update Customer</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('customer/add') }}">Add New Customer</a>
  </li>
  
</ul><br>
    <h3>Update Customer</h3>
    <a href="{{ url('customer/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Customers</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('customer/update') }}" method="post">
        {{ csrf_field() }}
        @foreach($customers  as $customer)
        <input type="hidden" name="rec_id" value="{{ $customer->id }}">
       <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                <label>Customer id</label>
                <input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_customer_id" value="{{ $customer->customer_id }}" class="form-control" placeholder="Enter Customer id">
            </div>
            </div>
            <div class="col-md-3">
               <div class="form-group">
                <label>Customer Name</label>
                <input type="text" required="required"  name="txt_customer_name" value="{{ $customer->customer_name }}" class="form-control" placeholder="Enter Customer Name">
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Credit Limit</label>
                <input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_credit_limit" value="{{ $customer->credit_limit }}" class="form-control" placeholder="Enter Customer Credit Limit">
            </div>
            </div>
        </div>
        @endforeach
        <div class="row"><div class="col-md-9"></div><div class="col-md-3"><button class="btn btn-block btn-success">Update</button></div></div>
    </form>
@stop
<script type="text/javascript">
    function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>