@extends('layouts.master')

@section('title', 'Accounts System-Customers')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('customer/show') }}">View Customers</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Add New Customer</a>
  </li>
  
</ul><br>
    <h3>Add New Customers</h3>
    <a href="{{ url('customer/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Customers</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    <form action="{{ url('customer/save') }}" method="post">
    	{{ csrf_field() }}
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                <label>Customer id</label>
                @foreach($auto_increment as $ai)
                <input type="number" name="txt_customer_id" class="form-control" value="{{ $ai->AUTO_INCREMENT }}" placeholder="Enter Customer id" autofocus>
                @endforeach
            </div>
            </div>
            <div class="col-md-3">
               <div class="form-group">
                <label>Customer Name</label>
                <input type="text" required="required" name="txt_customer_name" class="form-control" placeholder="Enter Customer Name">
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Credit Sales</label>
                <input type="checkbox" style="border:1px solid blue !important" name="txt_credit_sales" id="cr_limit_checkbox" class="form-control">
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Credit Limit</label>
                <input type="number" readonly="readonly" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_credit_limit" class="form-control" id='cr_limit_input' placeholder="Enter Customer Credit Limit">
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>No Credit Limit</label>
                <input type="checkbox" style="border:1px solid blue !important" name="txt_no_credit_limit" id="no_cr_limit" class="form-control">
            </div>
            </div>
           
        </div>
    <div class="row">
        <div class="col-md-9"></div>
        <div class="col-md-3">     
        <button class="btn btn-block btn-success" >Save</button>
        </div>
    </div>
    </form>
    
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).on('click','#cr_limit_checkbox',function(){
    // alert('working');
    if(!$(this).is(':checked')){
        $('#cr_limit_input').attr('readonly',true);
        $('#cr_limit_input').attr('required',false);
        $('#no_cr_limit').attr('disabled',false);
    }
    else{
        $('#cr_limit_input').attr('readonly',false);
        $('#cr_limit_input').attr('required',true);
        $('#no_cr_limit').attr('disabled',true);
    }
});

$(document).on('click','#no_cr_limit',function(){
    if(!$(this).is(':checked')){
       $('#cr_limit_input').attr('disabled',false);
       $('#cr_limit_checkbox').attr('disabled',false); 
    }
        else{
    $('#cr_limit_input').attr('disabled',true);
    $('#cr_limit_checkbox').attr('disabled',true);}
});


function isNumberKey(evt, obj) {

    var charCode = (evt.which) ? evt.which : event.keyCode
    var value = obj.value;
    var dotcontains = value.indexOf(".") != -1;
    if (dotcontains)
        if (charCode == 46) return false;
    if (charCode == 46) return true;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
</script>