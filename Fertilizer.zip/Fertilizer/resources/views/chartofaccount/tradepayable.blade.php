@extends('layouts.master')

@section('title', 'Accounts System-Trade Payable')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('coa/show') }}">Chart Of Account</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Trade Payable</a>
  </li>
 <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Trade Payable</h3> <a href="{{ url('coa/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Chart Of Account</a>
    <hr>
    <table class="table table-responsive">
        <tr>
            <th>Account id</th>
            <th>Account Name</th>
            <th>Balance</th>
        </tr>
        @foreach($payables as $payable)
        <tr>
            @if($payable->account_type == 3 && $payable->balance > 0 || $payable->account_type == 2 && $payable->balance > 0 )
            <td>{{ $payable->account_id }}</td>
            <td><a >{{ $payable->coa_title }}</a></td>
            <td><a >{{ $payable->balance }}</a></td>
            @elseif($payable->account_type == 1 && $payable->balance < 0 && strpos($payable->account_id, 'customer_') !== false)
             <td>{{ $payable->account_id }}</td>
            <td><a >{{ $payable->coa_title }}</a></td>
            <td><a >{{ $payable->balance }}</a></td>
            @endif
        </tr>
        @endforeach
    </table>
@stop
