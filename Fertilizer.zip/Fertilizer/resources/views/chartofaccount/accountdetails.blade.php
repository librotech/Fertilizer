@extends('layouts.master')

@section('title', 'Accounts System-Chart Of Account')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('coa/show') }}">View Chart Of Account</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Account Details</a>
  </li>
</ul><br>
    <h3>Account Details</h3> <a href="{{ url('coa/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Chart Of Account</a>
    <hr>
    <table class="table table-responsive">
        <tr>
            <th>ledger id</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
        @foreach($account_details as $acc_det)
        <tr>
            <?php
                if($acc_det->transection_type == 1){ 
                echo'<td><a href="'.url("purchase/view/$acc_det->id").'">'.$acc_det->id.'</a></td>';
                } 
                if($acc_det->transection_type == 2){ 
                echo'<td><a href="'.url("sales/view/$acc_det->id").'">'.$acc_det->id.'</a></td>';
                }
                 if($acc_det->transection_type == 3){ 
                echo'<td><a href="'.url("debitnotes/view/$acc_det->id").'">'.$acc_det->id.'</a></td>';
                } 
                 if($acc_det->transection_type == 4){ 
                echo'<td><a href="'.url("creditnotes/view/$acc_det->id").'">'.$acc_det->id.'</a></td>';
                } 
                if($acc_det->transection_type == 5){ 
                echo'<td><a href="'.url("ledgerentries/show/$acc_det->id").'">'.$acc_det->id.'</a></td>';
                }
                elseif ($acc_det->transection_type == 6) {
                echo'<td><a href="'.url("expense/view/$acc_det->id").'" >'.$acc_det->id.'</a></td>';
                }
                elseif ($acc_det->transection_type == 7) {
                echo'<td><a href="'.url("fundstransfer/show/$acc_det->id").'" >'.$acc_det->id.'</a></td>';
                }

            ?>
            <td>{{ $acc_det->debit_ammount }}</td>
            <td>{{ $acc_det->credit_ammount }}</td>
            <td>{{ $acc_det->balance }}</td>
            <td>{{ $acc_det->created_at }}</td>
        </tr>
        @endforeach
    </table>
@stop
