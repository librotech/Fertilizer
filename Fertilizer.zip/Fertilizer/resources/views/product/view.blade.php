@extends('layouts.master')

@section('title', 'Accounts System-Products')

@section('content')
<ul class="nav nav-tabs">
     <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Products</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('product/add') }}">Add New Product</a>
  </li>
 
</ul><br>
    <h3>All Products</h3> <a href="{{ url('product/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Product</a>
    <hr>
    
   
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            <th>SNo.</th>
            <th>Product id</th>
            <th>Product Name</th>
            <th>sale price</th>
            <th>stock alert</th>
            <th>User</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $product->product_id }}</td>
                <td>{{ $product->product_description }}</td>
                <td>{{ $product->sale_price }}</td>
                <td>{{ $product->stock_alert }}</td>
                <td>{{ $product->name }}</td>
                <td>{{ date('d-m-Y', strtotime($product->created_at))}}</td>
                <td><a href="{{ url('product/show/'.$product->product_id)}}" class="btn btn-success btn-sm">Edit</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('product/delete/'.$product->product_id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Product id</th>
            <th>Product Name</th>
            <th>sale price</th>
            <th>stock alert</th>
            <th>User</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>
    
    

@stop
