@extends('layouts.master')

@section('title', 'Accounts System-Products')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('product/show') }}">View Products</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Add New Product</a>
  </li>
  
</ul><br>
    <h3>Add New Product</h3>
     <a href="{{ url('product/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Products</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
     <form action="{{ url('product.store') }}" method="post">
        {{ csrf_field() }}
        <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Product Id</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" required="required" value="" name="txt_product_id" class="form-control" placeholder="Enter Product Id" autofocus>
            </div>
            </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" required="required" name="txt_product_description" class="form-control" placeholder="Enter Product Name">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Sale Price</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" required="required" name="txt_sale_price" class="form-control" placeholder="Enter Sale Price">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Stock Alert</label>
                <input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_stock_alert" class="form-control" placeholder="Enter Stock Alert">
            </div>
            
        </div>

        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3"><button class="btn btn-block btn-success">Save</button></div>
        </div>
        
    </form>
@stop
