@extends('layouts.master')

@section('title', 'Accounts System-Return Purchase')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active"  >Return Purchase</a>
      </li>
      <li class="nav-item">
        <a class="nav-link "  href="{{ url('debitnotes/view') }}">All Purchase return</a>
      </li>
      
    </ul>
<br>
    <h3>Return Purchase</h3>
    <a href="{{ url('debitnotes/view') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Purchase Return</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('debitnotes/save') }}" id="myForm" method="post">

    	<div class="row">
    	<div class="col-md-3">
    		<div class="form-group">
                <label>Supplier Name</label>
                <select class="form-control" required="required" name="txt_supplier" id="supplier">
                    <option value="">Select</option>
                    @foreach($suppliers as $supplier)
                    <option value="{{ $supplier->supplier_id }}">{{ $supplier->supplier_name }}</option>
                    @endforeach
                    
                </select>
            </div>
    		
    	</div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text" readonly="readonly" value="<?php echo "20".date('y-m-d', time()); ?>" id="datepicker" style="background:white !important;" name="txt_date" class="form-control">
            </div>
        </div>
        <div class="col-md-3">
        <div class="form-group">
            <label>Bill No</label>
            <input type="text" required="required" name="bill" class="form-control bill bill1" autocomplete="off" placeholder="Bill Id" list="bills"><datalist class="bills" id="bills" autofocus></datalist>
        </div>
        </div>
        <div class="col-md-6">
            
        </div>
        </div>
		<table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Product</th>
                    <th>Cost Price</th>
                    <th>Quantity</th>
                    <th>Amount</th>
                    <th>Add More</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                    <input type="text" required="required" data-id="1"  name="txt_product_id1" class="form-control product_id pro1" placeholder="Product" autocomplete="off" list="products">
                    <datalist class="products" class="pro1" id="products">
                    </datalist>
                    </td>
                    <td><input type="text" id="cost_price"  name="price1" class="form-control price p1" placeholder="Cost Price" readonly="readonly"></td>
                    <td><input type="text"  required="required" onkeypress="return isNumberKey(event,this)" id="qty1" name="qty1" class="form-control qty" placeholder="Product Quantity"></td>
                    <td><input type="number" id="ammount"  name="linetotal1" class="form-control txt_amount linetotal" readonly="readonly" placeholder="Amount"></td>
                    <td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

                </tr>
            </tbody>

        </table>
        <div class="row">
             <div class="col-md-6"></div>
             <div class="col-md-3">
                <div class="form-group" id="coamain"  style="display:none;">
                    <label><b>ChartofAccounts</b></label>
                    <select class="form-control" name="coa" id="coa">
                        @foreach($chartofaccounts as $chartofaccount)
                        <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                        @endforeach
                    </select>
                </div>
                
            </div>
            <div class="col-md-3">
               <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" id="total" name="total" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Return</b></label>
                    <input type="number" min="0"  onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number" readonly="readonly"  id="total_amount" name="total_amount" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
             <div class="col-md-9"></div>
            <div class="col-md-3"><button class="btn btn-block btn-success" id="save">save</button></div>
        </div>
        {{ csrf_field() }}
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

$(document).ready(function () {
    var counter = 1;
    $("#addrow").on("click", function (e) {
             counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'"  name="txt_product[]" class="form-control product_id pro'+counter+'" autocomplete="off" placeholder="Product Id" list="products"><datalist class="products" class="pro'+counter+'" id="products"></datalist></td>';
        cols += '<td><input type="number"  name="price[]" readonly="readonly" class="form-control price p'+counter+'"/></td>';
        cols += '<td><input type="text"  onkeypress="return isNumberKey(event,this)" id="qty'+counter+'" name="qty[]" class="form-control qty"/></td>';
        cols += '<td><input type="text" name="linetotal[]" readonly="readonly" class="form-control linetotal"/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
        
    });
    
    $("table.order-list").on("change", '.price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });
    var formProcessing = false;
    $("#myForm").on("submit", function(e) {
        
        e.preventDefault();
        
        if( formProcessing )
            return;

        formProcessing = true;
        $("#myForm").get(0).submit();
        
    });
});
    
function calculateRow(row) {
    var price = +row.find('.price').val();
    var qty = +row.find('.qty').val();
    row.find('.linetotal').val((price * qty).toFixed(2));
    
}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('.linetotal').each(function () {
        grandTotal += +$(this).val();
    });
    $("#total").val(grandTotal.toFixed(2));
  
    $("#cash_paid").keyup(function(){
        var cash_paid=$(this).val();
        if(cash_paid != ""){
            $('#coamain').show();
            $('#coa').attr('required','required');
        }
        if(cash_paid == ""){
            $('#coamain').hide();
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save_purchase').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
             $('#save_purchase').css('display','block');
            }
        }
       var grandTotal= $("#total").val();
       var final_ammount =grandTotal-cash_paid;
       $("#total_amount").val(final_ammount.toFixed(2));
    })
}
    
$(document).on('change', '#supplier', function(){
 var _token = $('input[name="_token"]').val();
    var supplier=this.value;
          $.ajax({
           type: 'POST',
            url: '{{ url("debitnotes/getsupbills") }}',
          data: { supplier:supplier,_token:_token },
          success: function(data){
            if(data != ""){
                $('.bills').html(data);
            }
            else{
                $('.bills').html("")
            }
         }
      });
});

$(document).on('change', '.bill', function(){
 var _token = $('input[name="_token"]').val();
    var bill=this.value;
    var bill_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
          url: '{{ url("debitnotes/getbillproducts") }}',
          data: { bill:bill,_token:_token },
          success: function(data){
            $('.products').html(data);
         }
      });
});

$(document).on('change', '.product_id', function(){
 var _token = $('input[name="_token"]').val();
    var product=this.value;
    var bill=$('.bill').val();
    var product_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
          url: '{{ url("debitnotes/getproductcostprice") }}',
          data: { product:product,bill:bill,_token:_token },
          success: function(data){
                      $('.p'+product_id).val(data);
         }
      });
});

function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1 && value.indexOf(".") != 0;

            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>