
@extends('layouts.master')

@section('title', 'Accounts System-View Sale')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('sale/show') }}">View Sales</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">View Sale</a>
  </li>
</ul><br>
    <h3>View Sale</h3>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form  id="myForm" method="post">
    @foreach($sales as $sale)
    	<div class="row">
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>invoice No</label>
    			<input type="text" name="txt_bill_no" value="{{ $sale->id }}" readonly="" class="form-control" placeholder="Enter Bill No">
    		</div>
        </div><div class="col-md-3">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text" id="datepicker" autocomplete="off" value="{{ $sale->date }}" name="txt_date" readonly="" class="form-control" placeholder="Enter Date of Bill">
    		</div>
    	</div>
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>customer Name</label>
                <input type="text" class="form-control"  readonly="readonly" value="{{ $sale->customer_name }}">
    		</div>
    	</div>

    	</div>
        @endforeach
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Product Id</th>
    				<th>Description</th>
    				<th>sale Price</th>
    				<th>Qty</th>
    				<th>Amount</th>
    			</tr>
    			</thead>
    			<tbody>
                @foreach($saleproducts as $saleproduct)
    			<tr>
    			
                    <td>
                    <input type="text" data-id="{{ $loop->iteration }}"  name="txt_product_id[]" class="form-control product_id" placeholder="Product Id" value="{{ $saleproduct->product_id }}" readonly="readonly" list="products">
                    </td>
    				<td><input type="text" value="{{ $saleproduct->product_description }}"  readonly="readonly" name="txt_product_description[]" class="form-control pro_des{{ $loop->iteration }}" placeholder="Product Description"></td>
    				<td><input type="text" id="cost_price" value="{{ $saleproduct->sale_price }}"   name="price[]" class="form-control price" readonly="readonly" placeholder="Cost Price"></td>

    				<td><input type="number" id="qty" name="qty[]" value="{{ $saleproduct->qty }}" readonly="readonly" class="form-control qty" placeholder="Product Quantity"></td>

    				<td><input type="number" id="ammount" value="{{ $saleproduct->inlinetotal }}" readonly="readonly" name="linetotal[]" class="form-control txt_amount linetotal" placeholder="Amount"></td>
    			</tr>
                @endforeach
    		</tbody>

    	</table>
        <hr>
        @foreach($sales as $sale)
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" value="{{ $sale->subtotal }}" id="total" name="total" readonly="" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Discount</b></label>
                    <input type="number" value="{{ $sale->discount  }}" readonly="readonly"  id="total_amount" name="total_amount" readonly="" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" value="{{ $sale->cashpaid }}" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" readonly="" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number" value="{{ $sale->duebalance  }}" readonly="readonly"  id="total_amount" name="total_amount" readonly="" class="form-control">
                </div>
            </div>
        </div>
        @endforeach
       <!--  <br>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-2"></div>
            <div class="col-md-3"></div>
            <div class="col-md-3"><button class="btn btn-block btn-info">print</button></div>
            
        </div> -->
        {{ csrf_field() }}
    </form>

@stop
