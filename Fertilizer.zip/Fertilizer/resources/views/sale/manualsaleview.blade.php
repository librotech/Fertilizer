@extends('layouts.master')
@section('title', 'Accounts System-sales')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('sale/show') }}">View Manual Sale</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Manual Sale Detail</a>
  </li>
</ul>
<br>
    <div class="row">
        <div class="col-md-10"><h3>Manual Sale Detail</h3></div>

         <div class="col-md-2"><a href="{{ url('sale/show') }}" class="btn btn-info btn-block" >View Manual  Sale</a></div>
         
        <div class="col-md-12"><hr></div>
    </div>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('sale/save') }}" id="myForm" method="post">
        <div id="myDiv">
    	<div class="row">
    	    @foreach($sales as $sale)
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Invoice No</label>
                
    			<input type="number" name="txt_inv_no" value="{{ $sale->id }}" class="form-control" readonly="readonly" id="inv_id">
                
    		</div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text" readonly="readonly" id="datepicker" value="{{ $sale->date }}"  name="txt_date"  class="form-control">
    		</div>
    	</div>
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Customer id</label>
               <input type="text"  data-id="1" readonly="readonly"  name="txt_customer_id" value="{{ $sale->customer }}" class="form-control" list="customers" id="cus">
    		</div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Customer name</label>
    			<input type="text" readonly="readonly" id="customer_name" name="txt_customer_description" value="{{ $sale->customer_name }}" class="form-control" placeholder="Enter Supplier Description">
    		</div>
    	</div>
        @endforeach
    	</div>
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				
    				<th>Description</th>
    				<th>Sale Price</th>
    				<th>Quantity</th>
    				<th>Amount</th>
    			</tr>
    			</thead>
    			<tbody>
    			@foreach($saledetails as $saledetail)
    			<tr>
    				
    				<td><input type="text"  name="txt_product_description1" tabindex="-1" class="form-control pro_des1" placeholder="Product Description" readonly="readonly" value="{{ $saledetail->description }}"></td>
    				<td><input readonly="readonly" type="number" min="0" value="{{ $saledetail->sale_price }}"  name="price1" class="form-control price s_price1" placeholder="sale Price"></td>
    				<td><input readonly="readonly" type="text" value="{{ $saledetail->qty }}" name="qty1" class="form-control qty pqty1" placeholder="Product Quantity"></td>
    				
    				<td><input type="number" id="ammount"  name="linetotal1" class="form-control txt_amount linetotal it1" readonly="readonly" value="{{ $saledetail->inlinetotal }}" placeholder="Amount"></td>

    			</tr>
    			@endforeach
    		</tbody>

    	</table>
        <hr>
        <div class="row">
            <div class="col-md-6"></div>
            @foreach($sales as $sale)
            <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coamain">
                  <label><b>Accounts Available</b></label>
                    <select class="form-control" name="coa"  id="coa">
                      
                    </select>  
                </div>
                
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" value="{{ $sale->subtotal }}" readonly="readonly" id="total" name="total" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" min="0" value="{{ $sale->cashpaid }}" readonly="readonly" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number"value="{{ $sale->duebalance }}" readonly="readonly"  id="total_amount" name="total_amount" class="form-control">
                </div>
            </div>
        </div>
        
        </div>
        <div class="row">
             <div class="col-md-6"></div>
             <div class="col-md-3"><!-- <p class="btn btn-block btn-info" id="print">Print</p> --></div>
            <div class="col-md-3"><a href="alert:id={{ $sale->id }}|4"  class="btn btn-block btn-success" >Print</a></div>
           @endforeach
            
        </div>
        {{ csrf_field() }}
    </form>
@stop
