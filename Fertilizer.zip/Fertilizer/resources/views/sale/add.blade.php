@extends('layouts.master')
@section('title', 'Accounts System-Add New sales')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('sale/show') }}">View Sale</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >New Sale</a>
  </li>
</ul><br>
    <h3>New Sales</h3>
    <a href="{{ url('sale/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Sale</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('sale/save') }}" id="myForm" method="post">
        <input type="hidden" name="date_bit" id="date_bit">
        <div id="myDiv">
    	<div class="row">
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Invoice No</label>
                @foreach($auto_increment as $ai)
    			<input type="number" name="txt_inv_no" value="{{ $ai->AUTO_INCREMENT }}" class="form-control" readonly="readonly" id="inv_id">
                @endforeach
    		</div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text" readonly="readonly" id="datepicker" value="<?php echo "20".date('y-m-d', time()); ?>" style="background:white !important;" name="txt_date" class="form-control">
    		</div>
    	</div>
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Customer id</label>
               <input type="text"  data-id="1" required="required"  name="txt_customer_id" value="{{ $walkincus->customer_id }}" class="form-control" list="customers" id="cus">
                    <datalist id="customers">
                    @foreach($customers as $customer)
                        <option value="{{ $customer->customer_id }}"><b>{{ $customer->customer_name }}</b></option>
                    @endforeach
                    </datalist>
    		</div>
        </div><div class="col-md-3">
    		<div class="form-group">
    			<label>Customer name</label>
    			<input type="text" readonly="readonly" id="customer_name" name="txt_customer_description" class="form-control" placeholder="Enter Supplier Description">
    		</div>
    	</div>

    	</div>
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Product</th>
    				<th>Description</th>
    				<th>Quantity</th>
                    <th>Sale Price</th>
    				<th>Amount</th>
    				<th>Add More</th>
    			</tr>
    			</thead>
    			<tbody>
    			<tr>
    				<td>
                    <input type="text" required="required" data-id="1"  name="txt_product_id1" class="form-control product_id" autocomplete="no" placeholder="Product" list="products" autofocus>
                    <datalist id="products">
                    @foreach($products as $product)
                        <option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>
                    @endforeach
                    </datalist>
                    </td>
    				<td><input type="text"  readonly="readonly" name="txt_product_description1" tabindex="-1" class="form-control pro_des1" placeholder="Product Description"></td>
    				<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="qty" name="qty1" class="form-control qty pqty1" placeholder="Product Quantity"></td>
                    <td><input required="required" type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" id="sale_price" tabindex="-1"  name="price1" class="form-control price s_price1" placeholder="Sale Price">

                        <input required="required" type="hidden" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" id="p_price" tabindex="-1"  name="p_price1" class="form-control p_price p_price1" placeholder="Sale Price">
                    </td>
    				<td><input type="number" id="ammount"  name="linetotal1" class="form-control txt_amount linetotal it1" readonly="readonly"  placeholder="Amount"></td>
    				<td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

    			</tr>
    		</tbody>

    	</table>
        <hr>
        <div class="row">
            <div class="col-md-6"></div>
            <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coamain">
                  <label><b>Accounts Available</b></label>
                    <select class="form-control" name="coa"  id="coa">
                        @foreach($chartofaccounts as $chartofaccount)
                        <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                        @endforeach
                    </select>  
                </div>
                
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" id="total" name="total" class="form-control">

                    <input type="hidden" readonly="readonly" id="discount_total" name="discount_total" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
            <style type="text/css"> 
            .cmn-toggle {
                    position: absolute;
                    margin-left: -9999px;
                    visibility: hidden;
                  }
                  .cmn-toggle + label {
                    display: block;
                    position: relative;
                    cursor: pointer;
                    outline: none;
                    user-select: none;
                  }
                  input.cmn-toggle-round + label {
                    padding: 2px;
                    width: 120px;
                    height: 40px;
                    background-color: #dddddd;
                    border-radius: 60px;
                  }
                  input.cmn-toggle-round + label:before,
                  input.cmn-toggle-round + label:after {
                    display: block;
                    position: absolute;
                    top: 1px;
                    left: 1px;
                    bottom: 1px;
                    content: "";
                  }
                  input.cmn-toggle-round + label:before {
                    right: 1px;
                    background-color: #f1f1f1;
                    border-radius: 60px;
                    transition: background 0.4s;
                  }
                  input.cmn-toggle-round + label:after {
                    width: 58px;
                    background-color: #fff;
                    border-radius: 100%;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
                    transition: margin 0.4s;
                  }
                  input.cmn-toggle-round:checked + label:before {
                    background-color: #8ce196;
                  }
                  input.cmn-toggle-round:checked + label:after {
                    margin-left: 60px;
                  }</style>
                
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Discount</b></label>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter Discount" id="discount" name="discount" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-6"></div>
            
            <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group" style="display:none;" id="coabal">
                    <label><b>Cash Available</b></label>
                <input type="number" readonly="readonly" name="cash_available" id="total_coa_balance" class="form-control">
                </div>
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number" readonly="readonly"  id="total_amount" name="total_amount" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Credit Sale</b></label>
                    <div class="switch">
                      <input id="cmn-toggle-1" class="cmn-toggle cmn-toggle-round" type="checkbox" name="creditsale">
                      <label for="cmn-toggle-1"></label>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="row">
             <div class="col-md-6"></div>
             <div class="col-md-3"><button id="save" name="save" class="btn btn-block btn-success" >Save</button></div>
            <div class="col-md-3"><button id="save_purchase" name="save" class="btn btn-block btn-success" >Save And Print</button></div>
            <input type="hidden" name="token" id="token">
            
        </div>
        {{ csrf_field() }}
    </form>
@stop
<!-- 
<img src='https://s3-eu-west-1.amazonaws.com/tpd/logos/5a683eff53596d00016d6dac/0x0.png' style='width:200px;height:80px;'> -->
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">


$(document).ready(function () {
    datecheck();
    $('#datepicker').change(function(){
        datecheck();
    });
    function datecheck(){
        var d = new Date();
        var month = d.getMonth()+1;
        var day = d.getDate();
        var output = d.getFullYear() + '-' +
        (month<10 ? '0' : '') + month + '-' +
        (day<10 ? '0' : '') + day;
        var input_date=$('#datepicker').val();
        if(output == input_date){
            $('#date_bit').val("1");
        }
        else{
            $('#date_bit').val("0");
        }
    }
    
    var counter = 1;
    $(".order-list").on("keydown",'.qty', function (e) {
        if( e.which == 9 || e.which == 13){
             counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'"  name="txt_product[]" class="form-control product_id" placeholder="Product Id" list="products" required autocomplete="no"><datalist id="products" autocomplete="no">@foreach($products as $product)<option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>@endforeach</datalist>';

        cols += '<td><input type="text" readonly="readonly"  name="product_description[]' + counter + '" tabindex="-1" class="form-control pdes pro_des'+counter+'" required/></td>';

        cols += '<td><input type="number"  name="price[]"  tabindex="-1" class="form-control price s_price'+counter+'" required/><input type="hidden"  name="p_price[]"  tabindex="-1" class="form-control p_price p_price'+counter+'" required/></td>';

        cols += '<td><input type="text"  onkeypress="return isNumberKey(event,this)" name="qty[]" class="form-control qty pqty'+counter+'" required/></td>';

        cols += '<td><input type="text" name="linetotal[]" readonly="readonly" class="form-control linetotal it'+counter+'" required/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
        }
    });
    
    $("table.order-list").on("change", '.price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'"  name="txt_product[]" class="form-control product_id" placeholder="Product Id" list="products" required autocomplete="no"><datalist id="products" autocomplete="no">@foreach($products as $product)<option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>@endforeach</datalist>';

        cols += '<td><input type="text" readonly="readonly"  name="product_description[]' + counter + '"  tabindex="-1" class="form-control pdes pro_des'+counter+'" required/></td>';

        cols += '<td><input type="number" tabindex="-1" name="price[]"  class="form-control price s_price'+counter+'" required/><input type="hidden"  name="p_price[]"  tabindex="-1" class="form-control p_price p_price'+counter+'" required/></td>';

        cols += '<td><input type="number" min="0" onkeypress="return isNumberKey(event,this)" name="qty[]" class="form-control qty pqty'+counter+'" required/></td>';

        cols += '<td><input type="text" name="linetotal[]" readonly="readonly" class="form-control linetotal it'+counter+'" required/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });
    
    $("table.order-list").on("change", '.price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });

    $('#cmn-toggle-1').change(function(){
        //alert('working');
        if($(this).prop('checked')){
            $('#save_purchase').css('display','block');
            $('#save').css('display','block');
        }
        else{
            $('#save_purchase').css('display','none');
            $('#save').css('display','none');
        }
    });
    var count=0;
    $('#save_purchase').on('click',function(){
        count++;
        
    });
    $('#token').val(count);

    var formProcessing = false;

    // jQuery("#myForm").on("submit", function(e) {
        
    //     e.preventDefault();
    //     print();
    //     if( formProcessing )
    //         return;

    //     formProcessing = true;
    //     jQuery("#myForm").get(0).submit();
        
    // });

});
    
function calculateRow(row) {
    var price = +row.find('.price').val();
    var qty = +row.find('.qty').val();
    row.find('.linetotal').val(Math.round(price * qty));
    
}

function calculateGrandTotal() {
    var grandTotal = 0;
    var final_ammount = 0;
    $("table.order-list").find('.linetotal').each(function () {
        grandTotal += +$(this).val();
        if($("#total_amount").val() == 0 ){
                $('#cmn-toggle-1').attr("disabled", true);
                $('#save_purchase').css('display','block');
                $('#save').css('display','block');
            }
           else if($("#total_amount").val() != 0){
            $('#cmn-toggle-1').attr("disabled", false);
            $('#save_purchase').css('display','none');
            $('#save').css('display','none');    
            }
    });

    $("#total").val(grandTotal.toFixed(2));
    $("#total_amount").val(grandTotal);
     var grandTotal= $("#total").val();
    
     $("#discount").keyup(function(){
        var afterdiscount=0;
        var discount=$(this).val();
        if(discount != 0){
           afterdiscount=grandTotal-discount-$("#cash_paid").val();
          $("#total_amount").val(afterdiscount);
          $("#discount_total").val(afterdiscount);
          
              if($("#total_amount").val() == 0 ){
                $('#cmn-toggle-1').attr("checked", false);
                $('#cmn-toggle-1').attr("disabled", true);
                $('#save_purchase').css('display','block');
                $('#save').css('display','block');
            }
           else if($("#total_amount").val() != 0){
            $('#cmn-toggle-1').attr("checked", false);
            $('#cmn-toggle-1').attr("disabled", false);
            $('#save_purchase').css('display','none'); 
            $('#save').css('display','none');   
            }
        }
        if(discount == ""){
            $("#total_amount").val(grandTotal-$("#cash_paid").val());
        }
       
    })
    $("#cash_paid").keyup(function(){
        var aftercashpaid=0;
        var cashpaid=$(this).val();
        if(cashpaid != 0){
          aftercashpaid = grandTotal-cashpaid-$("#discount").val();
          $("#total_amount").val(aftercashpaid);
        }
        if(cashpaid == ""){
            $("#total_amount").val(grandTotal-$("#discount").val());
        }

        if(cash_paid != ""){
            $('#coamain').show();
            $('#coabal').show();
            $('#coa').attr('required','required');
        }
        if($("#cash_paid").val() == ""){
            $('#coamain').hide();
            $('#coa').removeAttr('required','required');
            $('#coabal').hide();
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save_purchase').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
             $('#save_purchase').css('display','block');
            }
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save_purchase').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
             $('#save_purchase').css('display','block');
            }
        }
        if($("#total_amount").val() == 0){
                $('#cmn-toggle-1').attr("checked", false);
                $('#cmn-toggle-1').attr("disabled", true);
                $('#save_purchase').css('display','block');
                $('#save').css('display','block');
            }
           else if($("#total_amount").val() != 0){
            $('#cmn-toggle-1').attr("checked", false);
            $('#cmn-toggle-1').attr("disabled", false);
            $('#save_purchase').css('display','none');
            $('#save').css('display','none');    
            }
    })


}

$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();
     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#total_coa_balance').val("");
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    
});
$(document).on('change', '.product_id', function(){
 var _token = $('input[name="_token"]').val();
    var product=this.value;
    var pro_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
            dataType: 'json',
          url: '{{ url("purchase/products") }}',
          data: { product:product,_token:_token },
          success: function(data){
            // console.log(data);
            $.each(data[0], function(index,obj){

                $('.p_price'+pro_id).val(obj.sum/obj.count);
            })
            $.each(data[1], function(index,obj){

                $('.pro_des'+pro_id).val(obj.product_description);
                $('.s_price'+pro_id).val(obj.sale_price);
            })
            
            
         }
      });
});
$(document).ready(function () {
 var _token = $('input[name="_token"]').val();
    var cus=$('#cus').val();
          $.ajax({
           type: 'POST',
          url: '{{ url("sale/credit_cash") }}',
          data: { cus:cus,_token:_token },
          success: function(data){
            //alert(data);
            $('#customer_name').val(data[1]);
            if(data[0] == 0){
                $("#credit_cash").hide();
            }
            if(data[0] == 1){
                $("#credit_cash").show();
            }
         }
      });
});
$(document).on('change', '#cus', function(){
 var _token = $('input[name="_token"]').val();
    var cus=this.value;
          $.ajax({
           type: 'POST',
          url: '{{ url("sale/credit_cash") }}',
          data: { cus:cus,_token:_token },
          success: function(data){
            //alert(data);
            $('#customer_name').val(data[1]);
            if(data[0] == 0){
                $("#credit_cash").hide();
            }
            if(data[0] == 1){
                $("#credit_cash").show();
            }
         }
      });
});

function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }

</script>
  