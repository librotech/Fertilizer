
@extends('layouts.master')

@section('title', 'Accounts System-Purchase')

@section('content')
<ul class="nav nav-tabs">
 <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">New Purchase</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('purchase/show') }}">All Purchases Receipts</a>
  </li>
 
</ul><br>
    <h3>New Purchase</h3>
    <a href="{{ url('purchase/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View purchase</a>
    <hr>
    <p class="alert alert-danger error-message" style="display:none;"></p>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('purchase/save') }}" id="myForm" method="post">

    	<div class="row">
        
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Bill No</label>
    			<input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_bill_no"  class="form-control" placeholder="Enter Bill No" id="bill_id" autofocus>
    		</div>
        </div>
        <div class="col-md-3">
        
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text" value="<?php echo "20".date('y-m-d', time()); ?>" style="background:white !important;" readonly id="datepicker" autocomplete="off" name="txt_date" class="form-control date" placeholder="Enter Date of Bill">
    		</div>
    	</div>
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Supplier Name</label>
                <select class="form-control" required="required" name="txt_supplier" required="required" id="supplier">
                    
                </select>
    		</div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Suplier Address</label>
    			<input type="text"  readonly="readonly" id="supplier_description" name="txt_supplier_description" class="form-control" placeholder="Enter Supplier Description">
    		</div>
    	</div>
        
    	</div>
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Product</th>
    				<th>Name</th>
    				<th>Cost Price</th>
    				<th>Quantity</th>
    				<th>Amount</th>
                    <th>Expiry Date</th>
    				<th>Add More</th>
    			</tr>
    			</thead>
    			<tbody>
    			<tr>
    				<td>
                    <input type="text" data-id="1" required="required"  name="txt_product_id1" class="form-control product_id pro1" placeholder="Product" autocomplete="no" list="products">
                    <datalist class="products" id="products">
                    </datalist>
                    </td>
    				<td><input type="text"   readonly="readonly"  name="txt_product_description1" class="form-control pro_des1" tabindex="-1" placeholder="Product Description"></td>

    				<td><input type="text"  onkeypress="return isNumberKey(event,this)" required="required" min="0" id="cost_price"  name="price1" class="form-control price" placeholder="Cost Price"></td>

    				<td><input type="text"  required="required" id="qty" name="qty1" class="form-control qty" onkeypress="return isNumberKey(event,this)" placeholder="Product Quantity"></td>

    				<td><input type="number"  id="ammount" min="0" readonly="readonly" name="linetotal1" class="form-control txt_amount linetotal" placeholder="Amount"></td>

                    <td><input type="date" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="expiry_date" class="form-control" placeholder="Enter Expiry Date"></td>

    				<td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

    			</tr>
    		</tbody>

    	</table>
        <hr>
        <div class="row">
            <div class="col-md-6"></div>
            <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coamain">
                <label>Account</label>
                <select class="form-control" name="coa"  id="coa">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" id="total" name="total" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-6"></div>
            
            <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coabal">
                    <label>Cash Available</label>
                <input type="number"  readonly="readonly" name="cash_available" id="total_coa_balance" class="form-control">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number"  readonly="readonly"  id="total_amount" name="total_amount" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3"><button id="save_purchase" class="btn btn-block btn-success">Save</button></div>
            
        </div>
        {{ csrf_field() }}
    </form>
<!-- productmodal -->
<div id="productmodal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Product</h4>
        
      </div>
      <div class="modal-body">
        <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Product Id</label>
                <input type="text"  value="" id="p_id" name="txt_product_id" class="form-control" placeholder="Enter Product Id">
            </div>
            
            <div class="form-group">
                <label>Sale Price</label>
                <input type="text" id="s_p" name="txt_sale_price" class="form-control" placeholder="Enter Sale Price">
            </div>
            
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Product Description</label>
                <input type="text" id="p_d" name="txt_product_description" class="form-control" placeholder="Enter Product Description">
            </div>
            <div class="form-group">
                <label>Stock Alert</label>
                <input type="text" id="s_a" name="txt_stock_alert" class="form-control" placeholder="Enter Stock Alert">
            </div>
            
        </div>
        <div class="col-md-12"><div class="col-md-12"><p id="product_message"></p></div></div>
        </div>
       
      </div>
      <div class="modal-footer">
         <button class="btn  btn-success" id="addproduct">Save</button>
         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Supplier</h4>
        
      </div>
      <div class="modal-body">
        <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Suppplier Id</label>
                <input type="number" id="id"  name="txt_supplier_id" class="form-control" placeholder="Enter Suuplier Id">
            </div>
            <div class="form-group">
                <label>Supplier Name</label>
                <input type="text" id="name" name="txt_supplier_name" class="form-control" placeholder="Enter Supplier Name">
            </div>
            
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" id="address" style="overflow:auto;resize:none" rows="3" cols="3" name="supplier_address"></textarea>
            </div> 
        </div>
        <div class="col-md-12"><p id="supplier_message"></p></div>
        </div>
       
      </div>
      <div class="modal-footer">
            <button class="btn  btn-success" id="add_supplier">Save</button>
            <button type="button"  class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function () {
    populate_supplier();
    populate_products();
    var counter = 1;
    $(".order-list").on("keydown",'.qty', function (e) {
        if( e.which == 9 || e.which == 13){
             counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'" name="txt_product[]" class="form-control product_id pro'+counter+'" autocomplete="no" placeholder="Product" required list="products"><datalist class="products" id="products"></datalist>';

        cols += '<td><input tabindex="'+counter+'" type="text"  readonly="readonly"  name="product_description[]' + counter + '" required  class="form-control pro_des'+counter+'" /></td>';

        cols += '<td><input type="text"  onkeypress="return isNumberKey(event,this)" name="price[]" class="form-control price" required/></td>';

        cols += '<td><input type="text" onkeypress="return isNumberKey(event,this)" name="qty[]" class="form-control qty" required/></td>';
        cols += '<td><input type="text"  name="linetotal[]" readonly="readonly" class="form-control linetotal" required/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
        }
    });
    
    $("table.order-list").on("change", '.price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'"  name="txt_product[]" class="form-control product_id pro'+counter+'" autocomplete="no" placeholder="Product" list="products" required><datalist class="products" id="products"></datalist>';

        cols += '<td><input type="text"  readonly="readonly"  name="product_description[]' + counter + '" class="form-control pro_des'+counter+'" tabindex="-'+counter+'" required/></td>';

        cols += '<td><input type="text"  onkeypress="return isNumberKey(event,this)"  name="price[]" class="form-control price" required/></td>';

        cols += '<td><input type="number" min="0"   onkeypress="return isNumberKey(event,this)" name="qty[]" class="form-control qty" required/></td>';

        cols += '<td><input type="text"  name="linetotal[]" readonly="readonly" class="form-control linetotal" required/></td><input type="hidden" name="counter[]" value="'+counter+'" >';

        cols += '<td><input type="date" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="expiry_date" class="form-control" placeholder="Enter Expiry Date">'

        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });
    
    $("table.order-list").on("change", '.price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });
});
    
function calculateRow(row) {
    var price = +row.find('.price').val();
    var qty = +row.find('.qty').val();
    row.find('.linetotal').val((price * qty).toFixed(2));
    
}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('.linetotal').each(function () {
        grandTotal += +$(this).val();
    });
    $("#total").val(grandTotal.toFixed(2));
    $("#total_amount").val(grandTotal.toFixed(2));
    $("#cash_paid").keyup(function(){
        var cash_paid=$(this).val();
        if(cash_paid != ""){
            $('#coamain').show();
            $('#coabal').show();
             $('#coa').attr('required','required');
        }
        if(cash_paid == ""){

            $('#coamain').hide();
             $('#coabal').hide();
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save_purchase').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
             $('#save_purchase').css('display','block');
            }
        }
       var grandTotal= $("#total").val();
       var final_ammount =grandTotal-cash_paid;
       $("#total_amount").val(final_ammount.toFixed(2));
    })
}
$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();
     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#total_coa_balance').val("");
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    
});
$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    $("#supplier").change(function(){
        var supplier=this.value;
         $.ajax({
          type: 'POST',
          url: '{{ url("purchase/populate_supplier_description") }}',
          data: { supplier:supplier,_token:_token },
          success: function(data){
              $("#supplier_description").val(data);
         }
        });

         if(supplier == "add_supplier"){
            $('#myModal').modal('show');
            $("option:selected").removeAttr("selected");
         }
    });
      
});
$(document).on('change', '.product_id', function(){
 var _token = $('input[name="_token"]').val();
    var product=this.value;
    var pro_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
            dataType: 'json',
          url: '{{ url("purchase/products") }}',
          data: { product:product,_token:_token },
          success: function(data){
            $('.pro_des'+pro_id).val(data[1]);
            $('.pro_des'+pro_id).val(data[1]);
         }
      });
    if(product == "add_product"){
            $('#productmodal').modal('show');
            $('.pro'+pro_id).val("");
            
         }
});

$(document).on('click','#add_supplier',function(){
    var _token = $('input[name="_token"]').val();
    var supplier_id=$("#id").val();
    var supplier_name=$("#name").val();
    
    var supplier_address=$("#address").val();
    if(supplier_id == "" || supplier_name == ""  || supplier_address == ""){
        $("#supplier_message").attr('class','alert alert-danger');
        $("#supplier_message").html('All Fields Are Required'); 
    }
    else{

        $.ajax({
           type: 'POST',
           url: '{{ url("purchase/addsupplier") }}',
            data: {supplier_id:supplier_id,supplier_name:supplier_name,supplier_address:supplier_address,_token:_token },
          success: function(data){
            if(data == "0"){
                 $("#supplier_message").attr('class','alert alert-danger');
            $("#supplier_message").html('This Supplier Already Available Please Try Changed Supplier Id');
            }
            else{

                 $("#supplier_message").attr('class','alert alert-success');
            $("#supplier_message").html('New Supplier was successfully added!');
            populate_supplier();
            }
            
         }
      });
       
    }
});

$(document).on('click','#addproduct',function(){
    var _token = $('input[name="_token"]').val();
    var product_id=$("#p_id").val();
    var product_description=$("#p_d").val();
    var sale_price=$("#s_p").val();
    var stock_alert=$("#s_a").val();
    if(product_id == "" || product_description == "" || sale_price == "" || stock_alert == ""){
        $("#product_message").attr('class','alert alert-danger');
        $("#product_message").html('All Fields Are Required'); 
    }
    else{
        $.ajax({
           type: 'POST',
           url: '{{ url("purchase/addproduct") }}',
            data: {product_id:product_id,product_description:product_description,sale_price:sale_price,stock_alert:stock_alert,_token:_token },
          success: function(data){
            if(data == "0"){
                 $("#product_message").attr('class','alert alert-danger');
            $("#product_message").html('This Product Already Available Please Try Changed Product Id');
            }
            else{
            $("#product_message").attr('class','alert alert-success');
            $("#product_message").html('New Product was successfully added!');
            populate_products();
            }
            
         }
      });
    }
});


function populate_supplier(){
    $.ajax({    //create an ajax request to display.php
        type: "GET",
        url: "{{ url('supplier/allsuppliers') }}",             
        success: function(response){                    
            $("#supplier").html(response); 
        }

    });
}

function populate_products(){
    $.ajax({    //create an ajax request to display.php
        type: "GET",
        url: "{{ url('product/allproducts') }}",             
        success: function(response){                    
            $(".products").html(response); 
        }

    });
}

function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>