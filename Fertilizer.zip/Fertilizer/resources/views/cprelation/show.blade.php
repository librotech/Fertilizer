<style type="text/css">
    input{
        border:none;
    }
</style>
@extends('layouts.master')

@section('title', 'Accounts System-Relate Accounts')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Add Cash Paid Relationship</a>
  </li>
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Add Cash Paid Relationship</h3>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <hr>
    <div class="row">
        <div class="col-md-12">
          <form action="{{ url('cprelation/add') }}" method="post">
    {{ csrf_field() }}
    <table class="table table-responsive">
        <tr>
            <th>Asset Account Id</th>
            <th>Asset Account Title</th>
            <th>Add Relation To Cash Paid</th>
            <th>Make It Default</th>
        </tr>
        @foreach($chartofaccounts as $chartofaccount)
            <tr>
                <td><input type="text" readonly="readonly" name="id[]" value="{{ $chartofaccount->coa_id }}"></td>
                <td><input type="text" readonly="readonly" name="title[]" value="{{ $chartofaccount->coa_title }}"></td>
                <td><input type="checkbox" name="relate[]" value="{{ $loop->iteration-1 }}" class="form-control"></td>
                <td><input type="radio" name="default" value="{{ $chartofaccount->coa_id }}" class="form-control"></td>
                
            </tr>
        @endforeach
    </table>
    <button class="btn btn-success btn-right">Save</button>
   </form>   
        </div>
        <br>
        <div class="col-md-12">
        <h3>All Cash Paid Relations</h3>
   <table class="table table-responsive">
        <tr>
            <th>Asset Account Id</th>
            <th>Asset Account Title</th>
            <th>Remove Relation</th>
        </tr>
        @foreach($cprelations as $cprelation)
            <tr>
                <td><input type="text" readonly="readonly" name="id[]" value="{{ $cprelation->acc_id }}"></td>
                <td><input type="text" readonly="readonly" name="title[]" value="{{ $cprelation->acc_title }}"></td>
                <td><a href="{{ url('cprelation/delete/'.$cprelation->id) }}">Remove Relation</a></td>
            </tr>
        @endforeach
    </table>
        </div>
    </div>
  
   
@stop
<script type="text/javascript">
    $(document).ready(function(){
        var formProcessing = false;
        $("#myForm").on("submit", function(e) {
            
            e.preventDefault();
            
            if( formProcessing )
                return;

            formProcessing = true;
            $("#myForm").get(0).submit();
            
        });
    });
</script>