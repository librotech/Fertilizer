@extends('layouts.master')

@section('title', 'Accounts System-Employee Stitches Report')
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Employee Stitches Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
<div id="HTMLtoPDF" style="width:100%">
<h3>Employee Stitches Report</h3>
<hr>

</div>
<ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Employees Stitch</a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Employees Stitch</a>
        </li> -->
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Employee Stitch</a>
        </li>
        <!-- <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
         
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li> -->
    </ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="tableheadtext">Monthly Employee Stitches</h3>
    <hr>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Employee</th>
            <th>Stitches</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody id="cashsale">
       	@foreach($employeestitchs as $employeestitch)
       	<tr>
       		<td>{{ $loop->iteration }}</td>
       		<td>{{ $employeestitch->name }}</td>
       		<td>{{ $employeestitch->stiches }}</td>
       		<td>{{ $employeestitch->date }}</td>
       	</tr>
       	@endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Employee</th>
            <th>Stitches</th>
            <th>Date</th>
            </tr>
        </tfoot>
        
    </table>
   
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('#daily').click(function(){
        $.ajax({
            url:'{{ url("report/dailyemployeestitches") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<hr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+ obj.name +"</td><td>"+ obj.stiches +"</td><td>"+ obj.date +"</td></tr>";

                   count++;
                });
                $('#tableheadtext').html('Daily Employee Stitches');
                $('#cashsale').html(row);
            }

        })
    });

    // $('#weekly').click(function(){
    //     $.ajax({
    //         url:'{{ url("report/weeklyemployeestitches") }}',
    //         type:'get',
    //         datatype:'json',
    //         success:function(response){
    //             var count=1;
    //             var total=0;
    //             var row="";
    //              $.each(response, function (index, obj) {
    //                 row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

    //                count++;
                  
    //             });
     
    //             $('#cashsale').html(row);
    //         }

    //     })
    // });

    $('#monthly').click(function(){
       $.ajax({
            url:'{{ url("report/monthlyemployeestitches") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="";
                 $.each(response, function (index, obj) {
                     row += "<tr><td>"+count+"</td><td>"+ obj.name +"</td><td>"+ obj.stiches +"</td><td>"+ obj.date +"</td></tr>";

                   count++;
                  
                });
     			$('#tableheadtext').html('Monthly Employee Stitches');
                $('#cashsale').html(row);
            }

        })
    });

    // $('#datereport').click(function(){
    //     var _token = $('input[name="_token"]').val();
    //     var fromdate=$('#datepicker').val();
    //     var todate=$('#datepicker2').val();
    //     $.ajax({
    //         url:'{{ url("report/datecashsalereport") }}',
    //         type:'post',
    //         data:{fromdate:fromdate,todate:todate,_token:_token},
    //         datatype:'json',
    //         success:function(response){
    //             var count=1;
    //             var total=0;
    //             var row="";
    //              $.each(response, function (index, obj) {
    //                 row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

    //                count++;
                  
    //             });
     
    //             $('#cashsale').html(row);
    //         }

    //     })
    // });
});
</script>