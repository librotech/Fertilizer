@extends('layouts.master')

@section('title', 'Accounts System-Stocks Report')
<style type="text/css">
    
</style>
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Sales Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
    <h3>Stocks Reports</h3>
    <hr>
  
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="heading">Stocks</h3>
    <hr>

        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>

            <th>Sno.</th>
            <th>Product Name</th>
            <th>Cost Price</th>
            <th>Max Price</th>
            <th>Min Price</th>
            <th>Quantity</th>
            <th>% of total Assets</th>
        </tr>
        </thead>
        <tbody> 

        @foreach($purchases as $purchase)
          <tr>
            
            <td>{{$loop->iteration}}</td>
            <td> @if($purchase->status == 1)
                {{ $purchase->name}}
                @else
               {{$purchase->product_description}}
                @endif</td>
            <td>{{round(($purchase->cost1/$purchase->qty1) ,2)}}</td>

            <td>{{$purchase->max}}</td>
            <td>{{$purchase->min}}</td>
            <td>{{$purchase->qty}}</td>
            <td>{{round(((($purchase->qty/$purchase->cost)*$purchase->qty)/$mainTotal)*100,2)}}%</td>
              
          </tr>
          @endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Cost Price</th>
            <th>Max Price</th>
            <th>Min Price</th>
            <th>Quantity</th>
            <th>% of total Assets</th>
            
            </tr>
        </tfoot>
        
    </table>
   
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

// $(document).ready(function () {
//  var _token = $('input[name="_token"]').val();
//  $("#product").change(function(){
//     var product=$('#product').val();
//           $.ajax({
//            type: 'POST',
//           url: '{{ url("report/populate_product_description") }}',
//           dataType:'json',
//           data: { product:product,_token:_token },
//           success: function(data){
//             // alert(data);
//             $.each(data[0],function(index,obj){
//             $('#product_description').val(obj.product_description);
//         })
//             var row ='';
//             $.each(data[1],function(index,obj){
            

//                 row += 
//                     '<tr><td>'
//                     +obj.inv_bill_id+
//                     '</td><td>'
//                     +obj.inv_cost_price+
//                     '</td><td>'
//                     +obj.inv_qty+
//                     '</td></tr>'



//         })
//              $('#cashsale').html(row);
//          }  
//       });
// });
//  });
   

// $(document).ready(function(){
//     $('#daily').click(function(){
//         $.ajax({
//             url:'{{ url("report/dailycashsalereport") }}',
//             type:'get',
//             datatype:'json',
//             success:function(response){
//                 var count=1;
//                 var total=0;
//                 var row="<hr>";
//                  $.each(response, function (index, obj) {
//                     row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

//                    count++;
//                    total =total + obj.total;
//                 });
//                 row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr>";
//                 $('#cashsale').html(row);
//                 $('#heading').html('Daily Sales');
//             }

//         })
//     });

//     $('#weekly').click(function(){
//         $.ajax({
//             url:'{{ url("report/weeklycashsalereport") }}',
//             type:'get',
//             datatype:'json',
//             success:function(response){
//                 var count=1;
//                 var total=0;
//                 var row="";
//                  $.each(response, function (index, obj) {
//                     row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

//                    count++;
//                    total =total + obj.total;
//                 });
//                 row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr></table>";
//                 $('#cashsale').html(row);
//                 $('#heading').html('Weekly Sales');
//             }

//         })
//     });

//     $('#monthly').click(function(){
//        $.ajax({
//             url:'{{ url("report/monthlycashsalereport") }}',
//             type:'get',
//             datatype:'json',
//             success:function(response){
//                 var count=1;
//                 var total=0;
//                 var row="";
//                  $.each(response, function (index, obj) {
//                     row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

//                    count++;
//                    total =total + obj.total;
//                 });
//                 row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr></table>";
//                 $('#cashsale').html(row);
//                 $('#heading').html('Monthly Sales');
//             }

//         })
//     });

//     $('#datereport').click(function(){
//         var _token = $('input[name="_token"]').val();
//         var fromdate=$('#datepicker').val();
//         var todate=$('#datepicker2').val();
//         $.ajax({
//             url:'{{ url("report/datecashsalereport") }}',
//             type:'post',
//             data:{fromdate:fromdate,todate:todate,_token:_token},
//             datatype:'json',
//             success:function(response){
//                 var count=1;
//                 var total=0;
//                 var row="";
//                  $.each(response, function (index, obj) {
//                     row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

//                    count++;
//                    total =total + obj.total;
//                 });
//                 row +="<tr><th></th><th></th><th></th><th>Total</th><th>"+total+"</th></tr></table>";
//                 $('#cashsale').html(row);
//             }

//         })
//     });
// });

function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;


}
window.onafterprint = function(){
      window.location.reload(true);
 }

</script>