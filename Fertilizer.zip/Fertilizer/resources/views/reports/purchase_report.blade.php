@extends('layouts.master')

@section('title', 'Accounts System-Cash Purchase Report')
<style type="text/css">
    
</style>
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Purchase Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
    <h3>Purchase Reports</h3>
    <hr>
   <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Purchase</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Purchase</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Purchase</a>
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" placeholder="Select Date" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" placeholder="Select Date" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
        <!--  
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li> -->
    </ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="heading">Monthly Purchase</h3>
    <hr>
    <div class="row">
     <div class="col-md-3">
      <div class="form-group">
                <label>Supplier Id</label>
                <input class="form-control" required="required" name="txt_supplier" required="required" id="supplier"  placeholder="Select Supplier" class="form-control" list="suppliers">
                    <datalist id="suppliers">
                    @foreach($suppliers as $supplier)
                        <option value="{{ $supplier->supplier_id }}"><b>{{ $supplier->supplier_name }}</b></option>
                    @endforeach
                    </datalist> 
                </select>
            </div>
          </div>
           <div class="col-md-3">
            <div class="form-group">
                <label>Supplier Name</label>
                <input type="text"  readonly="readonly" id="supplier_description" name="txt_supplier_description" class="form-control" placeholder="Enter Supplier Description">
            </div>
        </div>
        <div class="col-md-3">
      <div class="form-group">
                <label>Product Id</label>
                <input class="form-control" required="required" name="txt_product" required="required" id="product"  placeholder="Select product" class="form-control" list="products">
                    <datalist id="products">
                    @foreach($products as $product)
                        <option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>
                    @endforeach
                    </datalist> 
                </select>
            </div>
          </div>
           <div class="col-md-3">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text"  readonly="readonly" id="product_description" name="txt_product_description" class="form-control" placeholder="Enter product Description">
            </div>
        </div>
        </div>
       <!--  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css"> -->
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Bill ID</th>
            <th>Supplier Name</th>
            <th>Name</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody id="cashsale">
        
    </tbody>
    <tfoot>
            <tr>
            <th>Bill ID</th>
            <th>Supplier Name</th>
            <th>Name</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Amount</th>
            <th>Date</th>
            </tr>
        </tfoot>
        
    </table>
   
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

$(document).ready(function(){
        $('#supplier,#datepicker,#datepicker2').on('change', function() {

        var _token   = $('input[name="_token"]').val();
        var supplier = $('#supplier').val();
        var to       = $('#datepicker').val();
        var from     = $('#datepicker2').val();

        if(supplier != ''){

            $.ajax({
            type: 'POST',
            url: '{{url("report/populate_supplier_description")}}',
            data: { 

                supplier,
                to,
                from,
                _token:_token

                 },
            dataType: 'json',
            success: function(data) {
                var row ='';
                $.each(data[0],function(i,obj){
                $('#supplier_description').val(obj.supplier_name);
            })

                $.each(data[2],function(i,obj){
                $('#product_description').val(obj.product_description);
            })

                $.each(data[1],function(i,obj){    
                    row += 

                            '<tr><td><a href="{{url("purchase/show/")}}/'+obj.bill_id+'">'
                            +obj.bill_id+
                            '</a></td><td>'
                            +obj.supplier_name+
                            '</td><td>'
                            +obj.product_description+
                            '</td><td>'
                            +obj.cost_price+
                            '</td><td>'
                            +obj.qty+
                            '</td><td>'
                            +obj.inlinetotal+
                            '</td><td>'
                            +obj.created_at+
                            '</td></tr>';
                      

                })
              
              $('#cashsale').html(row);
                }
            });
       }
    });
})
 

$(document).ready(function(){
    $('#product, #datepicker, #datepicker2').on('change' ,function(){


        var _token   = $('input[name="_token"]').val();
        var product = $('#product').val();
        var to      = $('#datepicker').val();
        var from    = $('#datepicker2').val();

        $.ajax({
            type:'post',
            url:'{{ url("report/populate_product") }}',
            data:{
                product,
                to,
                from,
                _token:_token
            },
            dataType:'json',
            success:function(data){
                $.each(data[0],function(index,obj){
                    $('#product_description').val(obj.product_description);
                })

                var row = '';
                 $.each(data[1],function(i,obj){
                    row += 

                        '<tr><td><a href="{{url("purchase/show/")}}/'+obj.bill_id+'">'
                        +obj.bill_id+
                        '</a></td><td>'
                        +obj.supplier_name+
                        '</td><td>'
                        +obj.product_description+
                        '</td><td>'
                        +obj.cost_price+
                        '</td><td>'
                        +obj.qty+
                        '</td><td>'
                        +obj.inlinetotal+
                        '</td><td>'
                        +obj.created_at+
                        '</td></tr>';                

                })

                 endRow = '';
                 $.each(data[2],function(index,obj){

                    // alert(data[2]);
                    endRow += 
                    '<tr><td></td><td>Average Cost Price</td><td></td><td>'
                    +obj.sum.toFixed(2)+
                    '</td></tr>'
                 })

                 $('#cashsale').html(row); 
                 $('#cashsale').append(endRow);
            }

        });
        });

});

function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;


}
window.onafterprint = function(){
      window.location.reload(true);
 }

</script>