@extends('layouts.master')

@section('title', 'Accounts System-Matchin Stitches Report')
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Machine Stitches Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
<div id="HTMLtoPDF" style="width:100%">
<h3>Machine Stitches Report</h3>
<hr>

</div>
<ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Machine Stitch</a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Employees Stitch</a>
        </li> -->
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Machine Stitch</a>
        </li>
        <!-- <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" value="{{ date('y-m-d') }}" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
         
        <li class="nav-item">&nbsp<a href="#" class="btn btn-info" id="datereport">Get Report</a></li> -->
    </ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="tableheadtext">Monthly Machine Stitch</h3>
    <hr>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Machine</th>
            <th>Stitches</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody id="cashsale">
       	@foreach($machinestitchs as $machinestitch)
       	<tr>
       		<td>{{ $loop->iteration }}</td>
       		<td>{{ $machinestitch->machine }}</td>
       		<td>{{ $machinestitch->stiches }}</td>
       		<td>{{ $machinestitch->date }}</td>
       	</tr>
       	@endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Machine</th>
            <th>Stitches</th>
            <th>Date</th>
            </tr>
        </tfoot>
        
    </table>
   
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('#daily').click(function(){
        $.ajax({
            url:'{{ url("report/dailymachinstitches") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="<hr>";
                 $.each(response, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td>"+obj.machine+"</td><td>"+ obj.stiches +"</td><td>"+ obj.date +"</td></tr>";

                   count++;
                });
                $('#tableheadtext').html('Daily Machine Stitches');
                $('#cashsale').html(row);
            }

        })
    });

    // $('#weekly').click(function(){
    //     $.ajax({
    //         url:'{{ url("report/weeklymachinstitches") }}',
    //         type:'get',
    //         datatype:'json',
    //         success:function(response){
    //             var count=1;
    //             var total=0;
    //             var row="";
    //              $.each(response, function (index, obj) {
    //                 row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

    //                count++;
                  
    //             });
     
    //             $('#cashsale').html(row);
    //         }

    //     })
    // });

    $('#monthly').click(function(){
       $.ajax({
            url:'{{ url("report/monthlymachinstitches") }}',
            type:'get',
            datatype:'json',
            success:function(response){
                var count=1;
                var total=0;
                var row="";
                 $.each(response, function (index, obj) {
                     row += "<tr><td>"+count+"</td><td>"+obj.machine+"</td><td>"+ obj.stiches +"</td><td>"+ obj.date +"</td></tr>";

                   count++;
                  
                });
     			$('#tableheadtext').html('Monthly Machine Stitches');
                $('#cashsale').html(row);
            }

        })
    });

    // $('#datereport').click(function(){
    //     var _token = $('input[name="_token"]').val();
    //     var fromdate=$('#datepicker').val();
    //     var todate=$('#datepicker2').val();
    //     $.ajax({
    //         url:'{{ url("report/datecashsalereport") }}',
    //         type:'post',
    //         data:{fromdate:fromdate,todate:todate,_token:_token},
    //         datatype:'json',
    //         success:function(response){
    //             var count=1;
    //             var total=0;
    //             var row="";
    //              $.each(response, function (index, obj) {
    //                 row += "<tr><td>"+count+"</td><td>"+ obj.id +"</td><td>"+obj.customer_name+"</td><td>"+ obj.total +"</td><td>"+ obj.created_at +"</td></tr>";

    //                count++;
                  
    //             });
     
    //             $('#cashsale').html(row);
    //         }

    //     })
    // });
});

function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;


}
window.onafterprint = function(){
      window.location.reload(true);
 }

</script>