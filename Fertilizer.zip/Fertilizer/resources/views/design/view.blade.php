@extends('layouts.master')

@section('title', 'Accounts System-Design')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('design/add') }}">Add New design</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">All designs</a>
      </li>
      
    </ul>
<br>
    <h3>All designs</h3> <a href="{{ url('design/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New design</a>
    <hr>
   <table id="example" class="table table-stripped">
        <thead>
        <tr>
    		<th>SNo.</th>
    		<th>design</th>
    		<th>User</th>
    		<th>Delete</th>
    		<th>Edit</th>
    	</tr>
        </thead>
        <tbody>
    	@foreach($designs as $design)
        <tr>
			<td>{{ $loop->iteration }}</td>
			<td>{{ $design->designncode }}</td>
			<td>{{ $design->name }}</td>
			<td><a href="{{ url('design/delete/'.$design->designncode) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
			<td><a href="{{ url('design/show/'.$design->designncode)}}" class="btn btn-success btn-sm">Edit</a></td>
		</tr>
    		
    	@endforeach
        </tbody>
        <tfoot>
            <tr>
                <th>SNo.</th>
                <th>design</th>
                <th>User</th>
                <th>Delete</th>
                <th>Edit</th>
            </tr>
        </tfoot>
    </table>
    {{-- {{ $designs->links() }} --}}

@stop
