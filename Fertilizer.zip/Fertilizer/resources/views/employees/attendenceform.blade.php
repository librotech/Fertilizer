@extends('layouts.master')

@section('title', 'Accounts System-Attendence')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link" href="{{ url()->previous() }}">Back</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Employees Attendance</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('employee/showattenedcebydate') }}">View Employee Attendance</a>
  </li>

</ul><br>
<h3>Employees Attendance</h3>
<form id="form" action="" method="POST">
  {{ csrf_field() }}
  <div class="row">
    <div class="col-md-3">
    <label for="date">Date</label>
      <input class="form-control" type="text" readonly="" value="<?php echo date('Y-m-d'); ?>" name="date" id="datepicker">
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label for="shift">Shift</label>
        <select id="shift" class="form-control" name="shift" required>
          <option value="">Select</option>
          <option value="day">day</option>
          <option value="night">night</option>
        </select>
      </div>
    </div>
  </div>
  <hr>

  <table class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>SNo.</th>
        <th>Employee Id</th>
        <th>Employee Name</th>
        <th>Attendence</th>
      </tr>
    </thead>
    <tbody id='result'>
    </tbody>
    <tfoot>
      <tr>
        <th>SNo.</th>
        <th>Employee Id</th>
        <th>Employee Name</th>
        <th>Attendence</th>
      </tr>
    </tfoot>
  </table>
</form>
<button type="button" class="btn btn-info" id="save">save</button>
<script type="text/javascript">
$(document).on('change','#shift',function(){
  var shift =$(this).val();
  var _token = $('input[name="_token"]').val();
    var date = $('#datepicker').val();
    $.ajax({
      type: 'POST',
      url: '{{ url("employee/showattenedce") }}',
      data: {
        shift: shift,
        _token: _token
      },
      success: function(data) {
        var count = 1;
        var row = "";
        $.each(data, function(index, obj) {
          row += "<tr><td>" + count + "</td><td><input type='text' readonly value=" + obj.id + " name='empid[]' class='form-control empid' data-id=" + count + "></td><td>" + obj.name + "</td><td><input type='checkbox' name='attend[]' class='form-control attend' checked='checked' id='attend_" + count + "'></td></tr>";

          count++;
        });
        $('#result').html(row);
      }
    });
});
  // $(document).ready(function() {
  //   var _token = $('input[name="_token"]').val();
  //   var shift = 'day';
  //   var date = $('#datepicker').val();
  //   $.ajax({
  //     type: 'POST',
  //     url: '{{ url("employee/showattenedce") }}',
  //     data: {
  //       shift: shift,
  //       _token: _token
  //     },
  //     success: function(data) {
  //       var count = 1;
  //       var row = "";
  //       $.each(data, function(index, obj) {
  //         row += "<tr><td>" + count + "</td><td><input type='text' readonly value=" + obj.id + " name='empid[]' class='form-control empid' data-id=" + count + "></td><td>" + obj.name + "</td><td><input type='checkbox' name='attend[]' class='form-control attend' checked='checked' id='attend_" + count + "'></td></tr>";

  //         count++;
  //       });
  //       $('#result').html(row);
  //     }
  //   });
  // });
  $(document).on('click', '.overtime', function() {
    var dataid = $(this).attr('data-id');
    if ($('#overtime_' + dataid).is(':checked')) {
      $('#attend_' + dataid).attr('checked', true);
      attendence = 1;
    } else {
      $('#attend_' + dataid).attr('checked', false);
      attendence = 0;
    }
  });
  $(document).on('click', '#save', function() {
    var _token = $('input[name="_token"]').val();
    var attendence = 0;
    var overtime = 0;
    var message = "";
    var data = $('#form').serialize();
    //var formdata = $(this).serialize(); // here $(this) refere to the form its submitting
    $.ajax({
      type: 'POST',
      url: '{{ url("employee/doattendence") }}',
      data: data, // here $(this) refers to the ajax object not form
      success: function(data) {
        alert('Attendence done');
        $('.attend').attr('checked', false);
        $('.overtime').attr('checked', false);
      },
    });
    // $('.empid').each(function(i,ob){
    //     var empid=$(this).val();
    //     var empdataid=$(this).attr('data-id');
    //     var attend=$('.attend_'+empdataid).val();
    //     var date=$('#datepicker').val();
    //     if($('#overtime_'+empdataid).is(':checked')){

    //        overtime=1;
    //     }
    //     else{
    //        overtime=0;
    //     }

    //     if($('#attend_'+empdataid).is(':checked')){
    //        attendence=1;
    //     }
    //     else{
    //        attendence=0;
    //     }
    //     $.ajax({
    //      type: 'POST',
    //      url: '{{ url("employee/doattendence") }}',
    //      data: { empid:empid,attendence:attendence,overtime:overtime,date:date,_token:_token },
    //      success: function(data){

    //      }
    //     });

    // })

  });
</script>
@stop
