@extends('layouts.master')
@section('title', 'Accounts System-Employee')
@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="{{ url('/home') }}">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="{{ url('employee/view') }}">All employees</a>
    </li>
    <li class="nav-item">
        <a class="nav-link active">Update employee</a>
    </li>

</ul>
<br>
<div class="col-md-12">
    <h3>Update employee</h3>
    <hr>
    @if(count($errors) > 0)
    @foreach($errors->all() as $error)
    <p class="alert alert-danger">{{ $error }}</p>
    @endforeach
    @endif
    @if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}">
        {!! session('message.content') !!}
    </div>
    @endif
    @foreach($employees as $employee)
    <form class="form-horizontal" method="POST" action="{{ url('employee/update') }}">
        {{ csrf_field() }}

        <input type="hidden" name="empid" value="{{ $employee->id }}">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input id="name" type="text" class="form-control" name="name" value="{{ $employee->name }}" required autofocus>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="email">Salary</label>
                    <input id="email" type="text" class="form-control" name="salary" value="{{ $employee->salary }}" required>
                </div>
            </div>
            <div class="col-md-3 col-md-offset-4">
                <div class="form-group">
                    <label for="Role">Available</label>
                    @php $checked='unchecked'; @endphp
                    @if($employee->available == 1)
                    @php $checked='checked'; @endphp
                    @else
                    @php $checked='unchecked'; @endphp
                    @endif

                    <input {{ $checked }} type='checkbox' name='available' class="form-control" />
                </div>
            </div>
            <div class="col-md-3 col-md-offset-4">
                <div class="form-group">
                    <label for="Role">Shift</label>
                    <select id="role" class="form-control" name="shift" required>
                    <option value="{{ $employee->shift }}">{{ $employee->shift }}</option>    
                    <option value="">Select</option>
                        <option value="day">day</option>
                        <option value="night">night</option>
                    </select>
                </div>
            </div>
            @endforeach
            <div class="col-md-12 ">
                <div class="form-group">

                    <button type="submit" class="btn btn-success">
                        Update employee
                    </button>
                </div>
            </div>
    </form>
</div>
</div>
</div>

@endsection