@extends('layouts.master')

@section('title', 'Accounts System-Return Sale')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Sale Return</a>
  </li>
</ul><br>
    <h3>Sale Return</h3>
    <!-- <a href="{{ url('sale/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Sales</a> -->
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('employee/returnsale') }}" id="myForm" method="post">
       <input type="hidden" name="date_bit" id="date_bit">
    	<div class="row">
        <div class="col-md-3">
            <div class="form-group">
               <label>Customer Name</label>
               <select class="form-control" id="cus" name="cus">
                <option value="">Select</option>
                @foreach($customers as $customer)
                <option value="{{ $customer->customer_id }}">{{ $customer->customer_name }}</option>
                @endforeach
                </select>
            </div>
        </div>
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Invoice No</label>
                <select class="form-control" id="invoice" name="inv">
                <option value="">Select</option>
                </select>
    		</div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Products</label>
                <select class="form-control" id="product" name="pro" required="">
 
                </select>
            </div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Quantity</label>
    			<input type="number" readonly="readonly"  id="qty" name="qty" class="form-control">
    		</div>
    	</div>
    	
         <div class="col-md-3">
                <div class="form-group">
                    <label><b>Return Quantity</b></label>
                    <input type="number" name="total" class="form-control">
                    <input type="hidden" name="cost_price" id="cost_price">
                </div>
            </div>

    	</div>
        <hr>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3">
                <!-- <label>Account</label>
                <select class="form-control" name="coa" id="coa" required="required">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                </select> -->
            </div>
           <!--  <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" id="total" class="form-control">
                </div>
            </div> -->
           <!--  <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" required="required" name="total" class="form-control">
                </div>
            </div> -->
        </div>
        <div class="row">
             <div class="col-md-9"></div>
            <div class="col-md-3"><button id="save_purchase" name="save" class="btn btn-block btn-success" >Return Sale</button></div>
            <input type="hidden" name="token" id="token">
            
        </div>
        {{ csrf_field() }}
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">


$(document).ready(function () {

    datecheck();
    $('#datepicker').change(function(){
        datecheck();
    });
    function datecheck(){
        var d = new Date();
        var month = d.getMonth()+1;
        var day = d.getDate();
        var output = d.getFullYear() + '-' +
        (month<10 ? '0' : '') + month + '-' +
        (day<10 ? '0' : '') + day;
        var input_date=$('#datepicker').val();
        if(output == input_date){
            $('#date_bit').val("1");
        }
        else{
            $('#date_bit').val("0");
        }
    }

    var formProcessing = false;

    jQuery("#myForm").on("submit", function(e) {
        
        e.preventDefault();
        
        if( formProcessing )
            return;

        formProcessing = true;
        jQuery("#myForm").get(0).submit();
        
    });
    $("#cash_paid").keyup(function(){
        var due=$("#due").val();
        var grandTotal= $("#total").val();
        if($('#cash_paid').val() !=""){
            $("#due").val($('#olddue').val() -$('#cash_paid').val());
        }
        if($('#cash_paid').val() ==""){
            $("#due").val(0);
        }
        if($("#due").val() < 0){
                $('#save_purchase').css('display','none');
            }
        else if($("#due").val() >= 0){
                $('#save_purchase').css('display','block');
            }
    })

    $('#cus').on('change',function(){
        var row="";
        var _token = $('input[name="_token"]').val();
        var customer_id=$(this).val();

        $.ajax({
            url:'{{ url("employee/getcustomerbalance") }}',
            method:'post',
            dataType: "json",
            data:{_token:_token,customer_id:customer_id},
            success:function(data){

                row += "<option value=''>Select</option>"
                $.each(data , function(index, obj){
                    row += "<option value="+ obj.id+">"+ obj.id+ " </option>";
                });
                $('#invoice').html(row);
            }   
        });

        // $.ajax({
        //     url:'{{ url("employee/customer_invoices") }}',
        //     method:'post',
        //     dataType: "json",
        //     data:{_token:_token,customer_id:customer_id},
        //     success:function(data){
        //             row +="<option>Select</option>";
        //        $.each(data, function (index, obj) {
        //             row += "<option value="+obj.id+">" + obj.id + "</option>";
                   
        //         });
        //           $('#invoice').html(row);
        //         }

        // });
    });
    $('#invoice').on('change',function(){
        var row = "";
        var _token = $('input[name="_token"]').val();
        var sale_invoice_number=$('#invoice').val();
        $.ajax({
            url:'{{ url("employee/stich_invoice") }}',
            method:'post',
            dataType: "json",
            data:{_token:_token,sale_invoice_number:sale_invoice_number},
            success:function(data){
                row +="<option value=''>Select</option>";
               $.each(data , function(index,obj){
                row += '<option value='+obj.product_id+'><b>'+obj.product_description+'</b></option>';
               });
               $('#product').html(row);
            }
        });
    });


    $('#product').on('change',function(){
        var row = "";
        var _token = $('input[name="_token"]').val();
        var sale_invoice_number=$('#product').val();
        var invoice = $('#invoice').val();
        $.ajax({
            url:'{{ url("employee/stich_items") }}',
            method:'post',
            dataType: "json",
            data:{_token:_token,sale_invoice_number:sale_invoice_number,invoice:invoice},
            success:function(data){
                // console.log(data);
                $.each(data , function(index,obj){
                    $('#qty').val(obj.qty);
                    $('#cost_price').val(obj.cost_price);
                });
            }
        });
    });
    // $('#invoice').on('change',function(){
    //     var row = "";
    //     var _token = $('input[name="_token"]').val();
    //     var sale_id=$(this).val();
    //         $.ajax({
    //             url:'{{ url("employee/stich_items") }}',
    //             method:'post',
    //             dataType: "json",
    //             data:{_token:_token,sale_id:sale_id},
    //             success:function(data){
    //                 //alert(data);
    //             $.each(data, function (index, obj) {
    //                 row += "<tr><td><input name='product[]' type='text' class='form-control' readonly value=" + obj.description + " ></td><td><input  type='text' class='form-control' readonly value=" + obj.m_type + "></td><td><input type='text' class='form-control' name='sprice[]' readonly value=" + obj.no_stiches + " ></td><td><input name='qty[]' type='text' class='form-control' readonly value=" + obj.rate + "></td><td><input type='text' name='inlinetotal[]' class='form-control' readonly value=" + obj.lenght + " ></td><td><input type='text' name='inlinetotal[]' class='form-control' readonly value=" + obj.total + " ></td></tr>";
                   
    //             });
    //              //alert(row);
    //                $('#products').html(row);
    //             }

    //         });
    // });
});

    
function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>