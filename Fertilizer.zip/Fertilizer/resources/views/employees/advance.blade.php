@extends('layouts.master')
@section('title', 'Accounts System-Employee')
@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Employee Advance Form</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ url('employee/view') }}">All Employees</a>
      </li>
      
    </ul>
<br>
<div class="col-md-12">
<h3>Employee Advance</h3>
<hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form class="form-horizontal" method="POST" action="{{ url('employee/storeadvance') }}">
                {{ csrf_field() }}
                <div class="row">
                <div class="col-md-3">
                   <div class="form-group">
                    <label for="Role">Employees</label>
                        <select id="emp"  class="form-control" name="emp" required>
                            <option value="">Select</option>
                            @foreach($employees as $employee)
                            <option value="{{ $employee->id }}">{{ $employee->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3 ">
                 <div class="form-group">
                    <label for="textbox">Date</label>
                    <input  type="text" class="form-control" readonly="" id="datepicker" name="date"  value="{{ '20'.date('y-m-d') }}" required>
                    </div>
                </div>
                <div class="col-md-3 ">
                 <div class="form-group">
                    <label for="textbox">Advance Amount</label>
                    <input id="advance" type="text" class="form-control" name="advance" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ old('stich') }}" required>
                    </div>
                </div>
                <div class="col-md-3"></div>
                <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coamain">
                <label><b>Accounts Available</b></label>
                <select class="form-control" name="coa"  id="coa">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coabal">
                    <label><b>Cash Available</b></label>
                <input type="number"  readonly="readonly" name="cash_available" id="total_coa_balance" class="form-control">
                </div>
            </div>
                <div class="col-md-12 ">
                <div class="form-group">
                    
                        <button type="submit" id="save_purchase" class="btn btn-success">
                           Save
                        </button>
                    </div>
                </div>
                  </form>
                </div>
            </div>
        </div>
   
@endsection
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function () {
  $('#advance').on('keyup',function(){
   var cash_paid=$(this).val();
        if(cash_paid != ""){
            $('#coamain').show();
            $('#coabal').show();
             $('#coa').attr('required','required');
        }
        if(cash_paid == ""){

            $('#coamain').hide();
             $('#coabal').hide();
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) < parseInt($("#advance").val()) ){
                $('#save_purchase').hide();
            }
            else if (parseInt(data) > parseInt($("#advance").val()) ) {
             $('#save_purchase').show();
            }
        }
       var grandTotal= $("#total").val();
       var final_ammount =grandTotal-cash_paid;
       $("#total_amount").val(final_ammount.toFixed(2));

  });
//     $("#total").val(grandTotal.toFixed(2));
//     $("#total_amount").val(grandTotal.toFixed(2));
//     $("#cash_paid").keyup(function(){
//         
//     })
 });
$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();
     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#advance").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#advance").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#total_coa_balance').val("");
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#advance").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#advance").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    
});
</script>