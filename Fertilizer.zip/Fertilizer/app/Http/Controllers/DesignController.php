<?php

namespace App\Http\Controllers;

use App\Design;
use App\Designdetail;
use Illuminate\Http\Request;
use Auth;
class DesignController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        return view('design/add');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $designs=Design::where('designncode',$request->desinecode)->first();
        if($designs != null){
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Design Code Already Available');
        }
        else{
            $storedesign=new Design;
            $storedesign->designncode =$request->desinecode;
            $storedesign->user_id = Auth::id();
            if($storedesign->save()){
                $design_id=Design::orderby('id','desc')->first();
                if(isset($request->description) && count($request->description) > 0){
                    for($i=0;$i < count($request->description);$i++){
                    
                            $designdetail = new Designdetail;
                            $designdetail->designcode=$design_id->designncode;
                            if(!empty($request->no_stitch[$i])){
                            $designdetail->no_stitch=$request->no_stitch[$i];
                             
                            }
                            else{
                                $designdetail->no_stitch=0;
                            }
                            
                            $designdetail->m_type=$request->mtype[$i];
                            if($request->mtype[$i] == 2.77)
                                $designdetail->three30_type=$request->three30[$i];
                            $designdetail->description=$request->description[$i];
                           
                            
                           $designdetail->save();
                           
                        }      
                    }

            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content','Design Code Saved');
            }
        }
        return redirect('design/add');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Design  $design
     * @return \Illuminate\Http\Response
     */
    public function show(Design $design)
    {
        $designs=Design::select('designs.*','users.name')->leftjoin('users','designs.user_id','=','users.id')->get();
        return view('design/view',compact('designs'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Design  $design
     * @return \Illuminate\Http\Response
     */
    public function edit($design)
    {
        $designs=Design::where('designncode',$design)->first();
        $designdetails=Designdetail::where('designcode',$design)->get();
        //return $designdetails;
        return view('design/edit',compact('designs','designdetails'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Design  $design
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $three30_type = null;
        $update=Design::where('designncode',$request->recid)->update(['designncode'=>$request->desinecode]);
        if($update){
            if(isset($request->description) && count($request->description) > 0){
                for($i=0;$i < count($request->description);$i++){
                    if($request->mtype[$i] == 2.77)
                        $three30_type=$request->three30[$i];

                    Designdetail::where('id',$request->subrecid[$i])->where('designcode',$request->recid)->update(['designcode'=>$request->desinecode,'description'=>$request->description[$i],'no_stitch'=>$request->no_stitch[$i],'m_type'=>$request->mtype[$i],'three30_type'=>$three30_type]);      
                }      
            }


            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content','Design Code Updated');
            return redirect('design/show/'.$request->desinecode);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Design  $design
     * @return \Illuminate\Http\Response
     */
    public function destroy($design)
    {
        $design=Design::where('designncode',$design)->delete();
        $design=Designdetail::where('designcode',$design)->delete();
        return redirect('Design/view');
    }
}
