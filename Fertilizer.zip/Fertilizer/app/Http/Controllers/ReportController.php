<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Sale;
use App\Expense;
use App\Ledger;
use App\Bill;
use App\Bill_product;
use App\Supplier;
use App\Saleproduct;
use App\Inventory;
use App\Customer;
use App\Product;
use Carbon\Carbon;
use DB;

class ReportController extends Controller
{
    public function index()
    {

        return view('reports/view');
    } 



    public function dailyexpensereport()
    {
        $query = "";
        $query = DB::raw('SELECT expenses.*,chartofaccounts.coa_title from expenses LEFT JOIN chartofaccounts on expenses.coa_id=chartofaccounts.coa_id where date(expenses.date) =CURDATE()');
        $expenses = DB::select($query);
        // $expenses = Expense::leftjoin('chartofaccounts','expenses.coa_id','=','chartofaccounts.coa_id')->whereDate('expenses.date', Carbon::today())->get();
        return $expenses;
    }

    public function weeklybalancereport()
    {
        $query = "";
        $query = DB::raw('SELECT expenses.*,chartofaccounts.coa_title from expenses LEFT JOIN chartofaccounts on expenses.coa_id=chartofaccounts.coa_id where YEARWEEK(expenses.date) = YEARWEEK(CURDATE())');
        $weeklyexpenses = DB::select($query);
        //  Carbon::setWeekStartsAt(Carbon::SUNDAY);
        // $weeklyexpenses  = Expense::leftjoin('chartofaccounts','expenses.coa_id','=','chartofaccounts.coa_id')->whereBetween('expenses.date', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])->get();
        return  $weeklyexpenses;
    }

    public function monthlybalancereport()
    {
        $query = "";
        $query = DB::raw('SELECT expenses.*,chartofaccounts.coa_title from expenses LEFT JOIN chartofaccounts on expenses.coa_id=chartofaccounts.coa_id where MONTH(expenses.date) = MONTH(CURRENT_DATE())');
        $monthlyexpenses = DB::select($query);
        // $currentMonth = date('m');
        // $monthlyexpenses =Expense::leftjoin('chartofaccounts','expenses.coa_id','=','chartofaccounts.coa_id')->whereRaw('MONTH(expenses.date) = ?',[$currentMonth])->get();
        return $monthlyexpenses;
    }

     public function purchase_report()
    {

        $suppliers = DB::table('suppliers')->get();
        $products = DB::table('products')->get();
        return view('reports/purchase_report', compact('suppliers','products'));
    }

     public function sales_report()
    {

        $customers = DB::table('customers')->get();
        $products = DB::table('products')->get();
        return view('reports/sale_report', compact('customers','products'));
    }

    public function stock_report(){

        // $products = DB::table('products')->get();
        $purchases = Inventory::select('inventories.*','products.*' )->leftjoin('products','products.product_id' ,'=', 'inventories.inv_product_id')
            ->selectRaw('inventories.* , SUM(inventories.inv_cost_price*inv_qty) as cost1 ,SUM(inv_qty) as qty1')
            ->selectRaw('inventories.* , MAX(inventories.inv_cost_price) as max , MIN(inventories.inv_cost_price) as min')
            ->selectRaw('inventories.* , SUM(inventories.inv_cost_price) as cost ,SUM(inv_qty) as qty')
            ->groupBy('inv_product_id')
            ->get();
            $avg = Inventory::selectRaw('(SUM(inv_qty)/SUM(inv_cost_price))*SUM(inv_qty) as total')->groupBy('inv_product_id')->get();
            $mainTotal = 0;
            foreach ($avg as $total) {
                $mainTotal = $mainTotal + $total->total;
            }
            //return $mainTotal;
            // $qty   = Inventory::selectRaw('SUM(inv_qty) as qty')->get();
            // return $avg;
        return view('reports/stock_report', compact('purchases' , 'mainTotal'));
    }

     public function populate_product_description(Request $request){

        // $product =DB::table('products')->where('product_id',$_POST['product'])->first()

        $product = Product::select('product_description')->where('product_id',$request->product)->get();

        $product_data = Inventory::where('inv_product_id', $request->product)->get();

        echo json_encode(array($product, $product_data));
        //returning product sale price,product description via ajax call against supplier id
         // echo json_encode(array($byproduct->product_description , $byproduct->byproduct_id , $byproduct->sale_price));
   
    }

      public function populate_supplier_description(Request $request){
        $supplier =Supplier::select('supplier_name')->where('supplier_id',$request->supplier)->get();


        if($request->to != '' && $request->from != '')
        {
                $purchases=Bill::select('bills.*','suppliers.supplier_name','bill_products.*','products.product_description')->leftjoin('bill_products','bills.bll_id','=','bill_products.bill_id')->leftjoin('products','products.product_id','=','bill_products.product_id')->leftjoin('suppliers','supplier_id','=','bills.supplier')->where('bills.supplier', $request->supplier)->where('bills.created_at' , '>=' , $request->to)->where('bills.created_at' , '<=' , $request->from)->get();    
            
       }
        else
            {

            $purchases=Bill::select('bills.*','suppliers.supplier_name','bill_products.*','products.product_description')->leftjoin('bill_products','bills.bll_id','=','bill_products.bill_id')->leftjoin('products','products.product_id','=','bill_products.product_id')->leftjoin('suppliers','supplier_id','=','bills.supplier')->where('bills.supplier', $request->supplier)->get();


            }

        
        

        echo json_encode(array($supplier, $purchases));
    }

    public function populate_product(Request $request){

        $product = Product::select('product_description')->where('product_id',$request->product)->get();

        if($request->to != '' && $request->from != '')
        {      
                $purchases = Bill_product::select('bill_products.*','bills.*','products.product_description','suppliers.supplier_name')->leftjoin('bills','bills.bll_id','=', 'bill_products.bill_id')->leftjoin('products','products.product_id' ,'=', 'bill_products.product_id')->leftjoin('suppliers','supplier_id','=','bills.supplier')->where('bill_products.product_id',$request->product)->where('bills.created_at' , '>=' , $request->to)->where('bills.created_at' , '<=' , $request->from)->get();   
       }
        else
            {
                $purchases = Bill_product::select('bill_products.*','bills.*','products.product_description','suppliers.supplier_name')->leftjoin('bills','bills.bll_id','=', 'bill_products.bill_id')->leftjoin('products','products.product_id' ,'=', 'bill_products.product_id')->leftjoin('suppliers','supplier_id','=','bills.supplier')->where('bill_products.product_id',$request->product)->get();
            }
        
        $pro = Bill_product::selectRaw('(SUM(cost_price*qty))/SUM(qty) as sum')->groupBy('product_id')->where('product_id',$request->product)->get();
            
        echo json_encode(array($product,$purchases,$pro));
    }

    public function populate_sales(Request $request){

            $product = Product::select('product_description')->where('product_id',$request->product)->get();

            if($request->to != '' && $request->from != '')
            {      
                    $sales = Saleproduct::select('saleproducts.*','sales.*','products.product_description','customers.customer_name')->leftjoin('sales','sales.id','=', 'saleproducts.inv_id')->leftjoin('products','products.product_id' ,'=', 'saleproducts.description')->leftjoin('customers','customer_id','=','sales.customer')->where('saleproducts.description',$request->product)->where('sales.created_at' , '>=' , $request->to)->where('sales.created_at' , '<=' , $request->from)->get();   
           }
            else
                {
                    $sales = Saleproduct::select('saleproducts.*','sales.*','products.product_description','customers.customer_name')->leftjoin('sales','sales.id','=', 'saleproducts.inv_id')->leftjoin('products','products.product_id' ,'=', 'saleproducts.description')->leftjoin('customers','customer_id','=','sales.customer')->where('saleproducts.description',$request->product)->get();
                }   

            $totalSales = Saleproduct::selectRaw('SUM(inlinetotal) as total')->where('saleproducts.description',$request->product)->get();


            echo json_encode(array($product,$sales,$totalSales));
        }

      public function populate_customer_description(Request $request){

       $customers =Customer::select('customer_name')->where('customer_id',$request->customer)->get();
       if($request->to != '' && $request->from != '')
        {
                $sales=Sale::select('sales.*','saleproducts.*','products.product_description','customers.customer_name')->leftjoin('saleproducts','sales.id','=','saleproducts.inv_id')->leftjoin('products','products.product_id','=','saleproducts.description')->leftjoin('customers','customer_id','=','sales.customer')->where('sales.customer',$request->customer)->where('sales.date' , '>=' , $request->to)->where('sales.date' , '<=' , $request->from)->get();
        }
        else{
        $sales=Sale::select('sales.*','saleproducts.*','products.product_description','customers.customer_name')->leftjoin('saleproducts','sales.id','=','saleproducts.inv_id')->leftjoin('customers','customer_id','=','sales.customer')->leftjoin('products','products.product_id','=','saleproducts.description')->where('sales.customer',$request->customer)->get();
}

        echo json_encode(array($customers,$sales));
    }



    public function dailyexpenses()
    {
        $query = DB::raw('SELECT expenses.*,chartofaccounts.coa_title from expenses LEFT JOIN chartofaccounts on expenses.coa_id=chartofaccounts.coa_id where MONTH(expenses.date) = MONTH(CURRENT_DATE())');
        $expenses = DB::select($query);
        return view('reports/expenses', compact('expenses'));
    }

    public function dateexpensereport(Request $request)
    {

        if ($request->fromdate != null && $request->todate) {
            $query = "";
            $query = DB::raw('SELECT expenses.*,chartofaccounts.coa_title from expenses LEFT JOIN chartofaccounts on expenses.coa_id=chartofaccounts.coa_id where date(expenses.date) in ("' . $request->fromdate . '","' . $request->todate . '")');
            $dateexpense = DB::select($query);
            // $dateexpense  = Expense::leftjoin('chartofaccounts','expenses.coa_id','=','chartofaccounts.coa_id')->whereBetween('expenses.date',[$request->fromdate,$request->todate])->get();
            if ($dateexpense != null) {
                return $dateexpense;
            }
        }
    }
    public function plreport()
    {
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $query = 0;
        $query2 = 0;
        $cosquery = "";
        $totalcos = 0;
        $currentMonth = date('m');
        $sales = 0;
        $sale = 0;
        $manual_sales = "";
        $manual_sales = Sale::sum('subtotal');
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101  GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $salequery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10101" ');
        $sales = DB::select($salequery);
        foreach ($sales as $sale) {
            $credit_sales = $sale->balance;
        }

        // $credit_sales=Stichinv::sum('total');

        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10102" ');

        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }

        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102"  GROUP BY x.account_id');
        $expenses = DB::select($query2);
        return view('reports/plreport', compact('incomes', 'cash_sales', 'credit_sales', 'totalcos', 'expenses', 'manual_sales'));
    }

    public function dailyplreport()
    {
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $query = 0;
        $query2 = 0;
        $cosquery = "";
        $totalcos = 0;
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && DATE(x.date) = CURDATE() GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $credit_sales = Sale::whereDate('date', Carbon::today())->sum('subtotal');
        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x  where x.account_id="10102" && DATE(x.date) = CURDATE() GROUP BY x.account_id ORDER BY x.account_type ASC');
        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }
        // $costofsales=Ledger::where('account_id','%product_%')->whereDate('date', Carbon::today())->sum('credit_ammount');
        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && x.account_id !=10102 && DATE(x.date) = CURDATE() GROUP BY x.account_id GROUP BY x.account_id');
        $expenses = DB::select($query2);
        $total_income = 0;
        $total_expenses = 0;
        echo '<h3>Daily Profit And Loss Report</h3><hr><h5>Income</h5>
  <table class="table table-hover" style="width:100%;text-align:left;">';

        foreach ($incomes as $income) {
            echo '<tr><td>' . $income->coa_title . '</td><td>' . $income->balance . '</td></tr>';
            $total_income += $income->balance;
        }
        echo '<tr><th>Total Income</th><td><b>' . $total_income . '</b></td></tr>
</table>
<h5>Sales</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><td>Sales</td><td>' . $credit_sales . '</td></tr>
<tr><th>Total Sales</th><td><b>' . ($credit_sales) . '</b></td></tr>
</table>
<h5>Revenue And Grossprofit</h5>

<table class="table table-hover" style="width:100%;text-align:left;">
<tr><td>Revenue</td><td>';
        echo $credit_sales + $total_income;
        echo '</td></tr>
<tr><td>Cost Of Sales</td><td>';
        echo $totalcos;
        echo '</td></tr>
<tr><th>Gross Profit</th><td><b>';
        $credit_sales + $total_income - $totalcos;
        echo '</b></td></tr>
</table>
<h5>Expense</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Expence</th><td></td></tr>';
        foreach ($expenses as $expense) {
            echo '<tr><td>' . $expense->coa_title . '</td><td>' . $expense->balance . '</td>';
            $total_expenses = $expense->balance;
        }
        echo '<tr><th>Total Expense</th><td><b>' . $total_expenses . '</b></td></tr>
</tr>
</table>
<h5>Net Profit</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Net Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos - $total_expenses . "&nbsp/- Grossprofit-Expense";
        echo '</b></td></tr>
</table>';
    }

    public function weeklyplreport()
    {
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $query = 0;
        $query2 = 0;
        $cosquery = "";
        $totalcos = 0;
        Carbon::setWeekStartsAt(Carbon::SUNDAY);
        Carbon::setWeekEndsAt(Carbon::SATURDAY);


        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);
        $credit_sales = Sale::whereBetween('date', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->sum('subtotal');


        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x  where x.account_id="10102" && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }


        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102" && YEARWEEK(x.date, 1) GROUP BY x.account_id');

        $expenses = DB::select($query2);
        $total_income = 0;
        $total_expenses = 0;
        echo '<h3>Weekly Profit And Loss Report</h3><hr><h5>Income</h5>
  <table class="table table-hover" style="width:100%;text-align:left;">';

        foreach ($incomes as $income) {
            echo '<tr><td>' . $income->coa_title . '</td><td>' . $income->balance . '</td></tr>';
            $total_income += $income->balance;
        }
        echo '<tr><th>Total Income</th><td><b>' . $total_income . '</b></td></tr>
</table>
<h5>Sales</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><td>Sales</td><td>' . $credit_sales . '</td></tr>
<tr><th>Total Sales</th><td><b>' . ($credit_sales) . '</b></td></tr>
</table>
<h5>Revenue And Grossprofit</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><td>Revenue</td><td>';
        echo $credit_sales + $total_income;
        echo '</td></tr>
<tr><td>Cost Of Sales</td><td>';
        echo  $totalcos;
        echo '</td></tr>
<tr><th>Gross Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos;
        echo '</b></td></tr>
</table>
<h5>Expense</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Expence</th><td></td></tr>';
        foreach ($expenses as $expense) {
            echo '<tr><td>' . $expense->coa_title . '</td><td>' . $expense->balance . '</td>';
            $total_expenses += $expense->balance;
        }
        echo '<tr><th>Total Expense</th><td><b>' . $total_expenses . '</b></td></tr>
</tr>
</table>
<h5>Net Profit</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Net Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos - $total_expenses . "&nbsp/- Grossprofit-Expense";
        echo '</b></td></tr>
</table>';
    }
    public function monthlyplreport()
    {
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $query = 0;
        $query2 = 0;
        $cosquery = "";
        $totalcos = 0;
        $currentMonth = date('m');

        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && x.date > DATE_SUB(NOW(), INTERVAL 1 MONTH) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $credit_sales = Sale::whereRaw('MONTH(date) = ?', [$currentMonth])->sum('subtotal');

        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10102"  &&  MONTH(x.date) =' . date("m") . '');

        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }

        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102" &&  x.date > DATE_SUB(NOW(), INTERVAL 1 MONTH) GROUP BY x.account_id');
        $expenses = DB::select($query2);
        $total_income = 0;
        $total_expenses = 0;
        echo '<h3>Monthly Profit And Loss Report</h3><hr><h5>Income</h5>
  <table class="table table-hover" style="width:100%;text-align:left;">';

        foreach ($incomes as $income) {
            echo '<tr><td>' . $income->coa_title . '</td><td>' . $income->balance . '</td></tr>';
            $total_income += $income->balance;
        }
        echo '<tr><th>Total Income</th><td><b>' . $total_income . '</b></td></tr>
</table>
<h5>Sales</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><td>Sales</td><td>' . $credit_sales . '</td></tr>
<tr><th>Total Sales</th><td><b>' . ($credit_sales) . '</b></td></tr>
</table>
<h5>Revenue And Grossprofit</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><td>Revenue</td><td>';
        echo $credit_sales + $total_income;
        echo '</td></tr>
<tr><td>Cost Of Sales</td><td>';
        echo $totalcos;
        echo '</td></tr>
<tr><th>Gross Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos;
        echo '</b></td></tr>
</table>
<h5>Expense</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Expence</th><td></td></tr>';
        foreach ($expenses as $expense) {
            echo '<tr><td>' . $expense->coa_title . '</td><td>' . $expense->balance . '</td>';
            $total_expenses += $expense->balance;
        }
        echo '<tr><th>Total Expense</th><td><b>' . $total_expenses . '</b></td></tr>
</tr>
</table>
<h5>Net Profit</h5>
<table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Net Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos - $total_expenses . "&nbsp/- Grossprofit-Expense";
        echo '</b></td></tr>
</table>';
    }

    public function datetodatepl(Request $request)
    {
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $query = 0;
        $query2 = 0;
        $cosquery = "";
        $totalcos = 0;
        $currentMonth = date('m');
        $sales = 0;
        $sale = 0;
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=4 && x.account_id !=10101  GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $salequery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where date(x.date) <= "' . date($request->todate) . '" && x.account_id="10101" ');
        $sales = DB::select($salequery);
        foreach ($sales as $sale) {
            $credit_sales = $sale->balance;
        }

        // $credit_sales=Stichinv::sum('total');

        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x   where date(x.date) <= "' . date($request->todate) . '" && x.account_id="10102" ');

        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }

        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102"  GROUP BY x.account_id');
        $expenses = DB::select($query2);
        $total_income = 0;
        $total_expenses = 0;
        echo '<h3>To ' . $request->todate . ' Profit And Loss Report</h3><hr><h5>Income</h5>
    <table class="table table-hover" style="width:100%;text-align:left;">';

        foreach ($incomes as $income) {
            echo '<tr><td>' . $income->coa_title . '</td><td>' . $income->balance . '</td></tr>';
            $total_income += $income->balance;
        }
        echo '<tr><th>Total Income</th><td><b>' . $total_income . '</b></td></tr>
    </table>
    <h5>Sales</h5>
    <table class="table table-hover" style="width:100%;text-align:left;">
    <tr><td>Sales</td><td>' . $credit_sales . '</td></tr>
    <tr><th>Total Sales</th><td><b>' . ($credit_sales) . '</b></td></tr>
    </table>
    <h5>Revenue And Grossprofit</h5>
    <table class="table table-hover">
    <tr><td>Revenue</td><td>';
        echo $credit_sales + $total_income;
        echo '</td></tr>
    <tr><td>Cost Of Sales</td><td>';
        echo  $totalcos;
        echo '</td></tr>
    <tr><th>Gross Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos;
        echo '</b></td></tr>
    </table>
    <h5>Expense</h5>
    <table class="table table-hover" style="width:100%;text-align:left;">
    <tr><th>Expence</th><td></td></tr>';
        foreach ($expenses as $expense) {
            echo '<tr><td>' . $expense->coa_title . '</td><td>' . $expense->balance . '</td>';
            $total_expenses += $expense->balance;
        }
        echo '<tr><th>Total Expense</th><td><b>' . $total_expenses . '</b></td></tr>
    </tr>
    </table>
    <h5>Net Profit</h5>
    <table class="table table-hover" style="width:100%;text-align:left;">
    <tr><th>Net Profit</th><td><b>';
        echo $credit_sales + $total_income - $totalcos - $total_expenses . "&nbsp/- Grossprofit-Expense";
        echo '</b></td></tr>
    </table>';
    }


    public function balancesheetreport()
    {
        $netprofit = 0;
        $sales = 0;
        $query = "";
        $query2 = "";
        $query3 = "";
        $query4 = "";
        $invtotal = 0;
        $queryy = "";
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $cosquery = "";
        $totalcos = 0;
        $total_income = 0;
        $total_expenses = 0;
        $currentMonth = date('m');
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101  GROUP BY x.account_id ORDER BY x.account_type ASC');

        $incomes = DB::select($query);
        foreach ($incomes as $income) {
            $total_income =$total_income + $income->balance;
        }
        // $credit_sales=Stichinv::sum('total');
        $salequery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10101" ');
        $sales = DB::select($salequery);
        foreach ($sales as $sale) {
            $credit_sales = $sale->balance;
        }
        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10102" ');

        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }

        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102"  GROUP BY x.account_id');
        $expenses = DB::select($query2);

        foreach ($expenses as $expense) {
            $total_expenses += $expense->balance;
        }
        $netprofit = $total_income + $credit_sales - $totalcos - $total_expenses;

        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=1  OR x.account_type=6   GROUP BY account_id ORDER BY x.account_type ASC');
        $assets = DB::select($query);
        $query3 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=3  GROUP BY account_id ORDER BY x.account_type ASC');
        $capitals = DB::select($query3);

        $query4 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.credit_ammount,ledgers.debit_ammount,ledgers.account_id,ledgers.transection_type,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=2  GROUP BY account_id ORDER BY x.account_type ASC');
        $liabilities = DB::select($query4);

        $query2 = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x where account_id LIKE "%product_%"   ORDER BY x.account_type ASC');
        $inv_total = DB::select($query2);
        foreach ($inv_total as $invto) {
            $invtotal += $invto->balance;
        }
        $queryy = DB::raw('SELECT x.*,chartofaccounts.*,fixedacounts.amo FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id LEFT JOIN fixedacounts on fixedacounts.ass_name=chartofaccounts.coa_description where x.account_type=5 && x.account_id LIKE "de_%"  GROUP BY account_id ORDER BY x.account_type ASC');
        $acu_expences = DB::select($queryy);
        return view('reports/balancesheet', compact('assets', 'invtotal', 'capitals', 'liabilities', 'netprofit', 'acu_expences'));
    }

    public function weeklybalancesheet()
    {

        $netprofit = 0;
        $sales = 0;
        $query = "";
        $query2 = "";
        $query3 = "";
        $query4 = "";
        $invtotal = 0;
        $queryy = "";
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $cosquery = "";
        $totalcos = 0;
        $total_income = 0;
        $total_expenses = 0;
        Carbon::setWeekStartsAt(Carbon::SUNDAY);
        Carbon::setWeekEndsAt(Carbon::SATURDAY);


        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $credit_sales = Sale::whereBetween('date', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->sum('subtotal');
        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x  where x.account_id="10102" && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }


        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102" && YEARWEEK(x.date, 1) GROUP BY x.account_id');

        $expenses = DB::select($query2);
        foreach ($expenses as $expense) {
            $total_expenses += $expense->balance;
        }
        $netprofit = $credit_sales + $total_income - $totalcos - $total_expenses;
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $credit_sales = Sale::whereBetween('date', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->sum('subtotal');
        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x  where x.account_id="10102" && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) GROUP BY x.account_id ORDER BY x.account_type ASC');
        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }


        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102" && YEARWEEK(x.date, 1) GROUP BY x.account_id');

        $expenses = DB::select($query2);
        foreach ($expenses as $expense) {
            $total_expenses += $expense->balance;
        }
        $netprofit = $credit_sales + $total_income - $totalcos - $total_expenses;
        echo '<hr><h5>Weekly Balancesheet</h5><table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Assets</th><td></td></tr>';
        foreach ($assets as $asset) {
            if ($asset->balance > 0) {
                echo '<tr><td>' . $asset->coa_title . '</td><td>' . number_format(round($asset->balance)) . '</td></tr>';
                $asset_total += round($asset->balance);
            }
        }
        foreach ($liabilities as $liability) {
            if ($liability->balance < 0) {
                if ($liability->transection_type != '10') {
                    echo '<tr><td>' . $liability->coa_title . '</td><td>' . number_format(round($liability->balance * -1)) . '</td></tr>';
                }
                $asset_total += round($liability->balance * -1);
            }
        }
        echo '<tr><th>Inventories Total</th><th> ' . round($invtotal) . ' </th></tr>
<tr><th>Sub Assets Total</th><th> ' . round($asset_total) . ' </th></tr>
<tr><th>Accumulative Expenses</th><td></td></tr>';
        foreach ($acu_expences as $acu_expence) {
            if ($acu_expence->balance > 0)
                echo '<tr><td>' . $acu_expence->coa_title . '</td><td>' . number_format(round($acu_expence->balance)) . '</td></tr>';
            $acu_expence_total += round($acu_expence->balance);
        }

        echo '<tr><th>Accumulative Total</th><th> ' . number_format(round($acu_expence_total)) . ' </th></tr>
<tr><th>Assets Total</th><th> ' . round($asset_total - $acu_expence_total) . ' </th></tr>
<tr><th>Capital Account</th><td></td></tr>';
        foreach ($capitals as $capital) {
            echo '<tr><td>' . $capital->coa_title . '</td><td>' . number_format(round($capital->balance)) . '</td></tr>';
            $capital_total += round($capital->balance);
        }

        echo '<tr><th>Capital Total</th><th> ' . number_format(round($capital_total)) . ' </th></tr>

<tr><th>Net Profit</th><td><b>' . number_format(round($netprofit)) . '</b></td></tr>
<tr><th>liability Account</th><td></td></tr>';
        foreach ($liabilities as $liability) {

            if ($liability->transection_type != '10') {
                if ($liability->balance > 0) {
                    echo '<tr><td>' . $liability->coa_title . '</td><td>' . number_format(round($liability->balance)) . '</td></tr>';
                }
            }
            if ($liability->transection_type == '10') {
                $employee_liability += round($liability->balance);
            }

            $liability_total += round($liability->balance);
        }
        foreach ($assets as $asset) {
            if ($asset->balance < 0) {
                echo '<tr><td>' . $asset->coa_title . '</td><td>' . number_format(round($asset->balance * -1)) . '</td></tr>';
                $liability_total += round($asset->balance * -1);
            }
        }
        echo '<tr><th>Outstanding Wages</th><th> ' . number_format(round($employee_liability)) . ' </th></tr><tr><th>Liability Total</th><th> ' . number_format(round($liability_total)) . ' </th></tr>
<tr><th>Final Total</th><th>' . number_format(round($capital_total + $netprofit + $liability_total)) . '</th></tr>

</table>';
    }
    public function dailybalancesheet()
    {
        $netprofit = 0;
        $sales = 0;
        $query = "";
        $query2 = "";
        $query3 = "";
        $query4 = "";
        $invtotal = 0;
        $queryy = "";
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $cosquery = "";
        $totalcos = 0;
        $total_income = 0;
        $total_expenses = 0;
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && DATE(x.date) = CURDATE() GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $credit_sales = Sale::whereDate('date', Carbon::today())->sum('subtotal');
        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x  where x.account_id="10102" && DATE(x.date) = CURDATE() GROUP BY x.account_id ORDER BY x.account_type ASC');
        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }
        // $costofsales=Ledger::where('account_id','%product_%')->whereDate('date', Carbon::today())->sum('credit_ammount');
        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && x.account_id !=10102 && DATE(x.date) = CURDATE() GROUP BY x.account_id');
        $expenses = DB::select($query2);
        foreach ($expenses as $expense) {
            $total_expenses += $expense->balance;
        }
        $netprofit = $credit_sales + $total_income - $totalcos - $total_expenses;
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=1 && YEARWEEK(x.date, 1) = YEARWEEK(CURDATE(), 1) OR x.account_type=6 && DATE(x.date) = CURDATE()  GROUP BY account_id ORDER BY x.account_type ASC');
        $assets = DB::select($query);
        $query3 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=3 && DATE(x.date) = CURDATE() GROUP BY account_id ORDER BY x.account_type ASC');
        $capitals = DB::select($query3);

        $query4 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.transection_type,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=2 && DATE(x.date) = CURDATE() GROUP BY account_id ORDER BY x.account_type ASC');
        $liabilities = DB::select($query4);

        $query2 = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x where account_id LIKE "%product_%" && DATE(x.date) = CURDATE()  ORDER BY x.account_type ASC');
        $inv_total = DB::select($query2);
        foreach ($inv_total as $invto) {
            $invtotal += $invto->balance;
        }
        $queryy = DB::raw('SELECT x.*,chartofaccounts.*,fixedacounts.amo FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id LEFT JOIN fixedacounts on fixedacounts.ass_name=chartofaccounts.coa_description where x.account_type=5 && x.account_id LIKE "de_%" && DATE(x.date) = CURDATE() GROUP BY account_id ORDER BY x.account_type ASC');
        $acu_expences = DB::select($queryy);
        $asset_total = 0;
        $capital_total = 0;
        $liability_total = 0;
        $acu_expence_total = 0;
        $employee_liability = 0;
        echo '<hr><h5>Daily Balancesheet</h5><table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Assets</th><td></td></tr>';
        foreach ($assets as $asset) {
            if ($asset->balance > 0) {
                echo '<tr><td>' . $asset->coa_title . '</td><td>' . number_format(round($asset->balance)) . '</td></tr>';
                $asset_total += round($asset->balance);
            }
        }
        foreach ($liabilities as $liability) {
            if ($liability->balance < 0) {
                if ($liability->transection_type != '10') {
                    echo '<tr><td>' . $liability->coa_title . '</td><td>' . number_format(round($liability->balance * -1)) . '</td></tr>';
                }
                $asset_total += round($liability->balance * -1);
            }
        }
        echo '<tr><th>Inventories Total</th><th> ' . round($invtotal) . ' </th></tr>
<tr><th>Sub Assets Total</th><th> ' . round($asset_total) . ' </th></tr>
<tr><th>Accumulative Expenses</th><td></td></tr>';
        foreach ($acu_expences as $acu_expence) {
            if ($acu_expence->balance > 0)
                echo '<tr><td>' . $acu_expence->coa_title . '</td><td>' . number_format(round($acu_expence->balance)) . '</td></tr>';
            $acu_expence_total += round($acu_expence->balance);
        }

        echo '<tr><th>Accumulative Total</th><th> ' . number_format(round($acu_expence_total)) . ' </th></tr>
<tr><th>Assets Total</th><th> ' . round($asset_total - $acu_expence_total) . ' </th></tr>
<tr><th>Capital Account</th><td></td></tr>';
        foreach ($capitals as $capital) {
            echo '<tr><td>' . $capital->coa_title . '</td><td>' . number_format(round($capital->balance)) . '</td></tr>';
            $capital_total += round($capital->balance);
        }

        echo '<tr><th>Capital Total</th><th> ' . number_format(round($capital_total)) . ' </th></tr>

<tr><th>Net Profit</th><td><b>' . number_format(round($netprofit)) . '</b></td></tr>
<tr><th>liability Account</th><td></td></tr>';
        foreach ($liabilities as $liability) {

            if ($liability->transection_type != '10') {
                if ($liability->balance > 0) {
                    echo '<tr><td>' . $liability->coa_title . '</td><td>' . number_format(round($liability->balance)) . '</td></tr>';
                }
            }
            if ($liability->transection_type == '10') {
                $employee_liability += round($liability->balance);
            }

            $liability_total += round($liability->balance);
        }
        foreach ($assets as $asset) {
            if ($asset->balance < 0) {
                echo '<tr><td>' . $asset->coa_title . '</td><td>' . number_format(round($asset->balance * -1)) . '</td></tr>';
                $liability_total += round($asset->balance * -1);
            }
        }
        echo '<tr><th>Outstanding Wages</th><th> ' . number_format(round($employee_liability)) . ' </th></tr><tr><th>Liability Total</th><th> ' . number_format(round($liability_total)) . ' </th></tr>
<tr><th>Final Total</th><th>' . number_format(round($capital_total + $netprofit + $liability_total)) . '</th></tr>

</table>';
    }

    public function monthlybalancesheet()
    {
        $netprofit = 0;
        $sales = 0;
        $query = "";
        $query2 = "";
        $query3 = "";
        $query4 = "";
        $invtotal = 0;
        $queryy = "";
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $cosquery = "";
        $totalcos = 0;
        $total_income = 0;
        $total_expenses = 0;
        $currentMonth = date('m');
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=4 && x.account_id !=10101 && Month(x.date) =' . date('m') . ' GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        $credit_sales = Sale::whereRaw('MONTH(date) = ?', [$currentMonth])->sum('subtotal');

        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where x.account_id="10102"  &&  MONTH(x.date) =' . date("m") . '');

        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }

        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102" &&  Month(x.date) =' . date('m') . ' GROUP BY x.account_id');
        $expenses = DB::select($query2);
        foreach ($expenses as $expense) {
            $total_expenses += $expense->balance;
        }
        $netprofit = $credit_sales + $total_income - $totalcos - $total_expenses;

        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=1 && Month(x.date) =' . date('m') . ' OR x.account_type=6 && Month(x.date) =' . date('m') . '  GROUP BY account_id ORDER BY x.account_type ASC');
        $assets = DB::select($query);
        $query3 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=3 && Month(x.date) =' . date('m') . ' GROUP BY account_id ORDER BY x.account_type ASC');
        $capitals = DB::select($query3);

        $query4 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date,ledgers.transection_type FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where x.account_type=2 && Month(x.date) =' . date('m') . ' GROUP BY account_id ORDER BY x.account_type ASC');
        $liabilities = DB::select($query4);

        $query2 = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x where account_id LIKE "%product_%" && Month(date) =' . date('m') . '  ORDER BY x.account_type ASC');
        $inv_total = DB::select($query2);
        foreach ($inv_total as $invto) {
            $invtotal += $invto->balance;
        }
        $queryy = DB::raw('SELECT x.*,chartofaccounts.*,fixedacounts.amo FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id LEFT JOIN fixedacounts on fixedacounts.ass_name=chartofaccounts.coa_description where x.account_type=5 && x.account_id LIKE "de_%" && Month(x.date) =' . date('m') . ' GROUP BY account_id ORDER BY x.account_type ASC');
        $acu_expences = DB::select($queryy);
        $asset_total = 0;
        $capital_total = 0;
        $liability_total = 0;
        $acu_expence_total = 0;
        $employee_liability = 0;
        echo '<hr><h5>Monthly Balancesheet</h5><table class="table table-hover" style="width:100%;text-align:left;">
<tr><th>Assets</th><td></td></tr>';
        foreach ($assets as $asset) {
            if ($asset->balance > 0) {
                echo '<tr><td>' . $asset->coa_title . '</td><td>' . number_format(round($asset->balance)) . '</td></tr>';
                $asset_total += round($asset->balance);
            }
        }
        foreach ($liabilities as $liability) {
            if ($liability->balance < 0) {
                if ($liability->transection_type != '10') {
                    echo '<tr><td>' . $liability->coa_title . '</td><td>' . number_format(round($liability->balance * -1)) . '</td></tr>';
                }
                $asset_total += round($liability->balance * -1);
            }
        }
        echo '<tr><th>Inventories Total</th><th> ' . round($invtotal) . ' </th></tr>
<tr><th>Sub Assets Total</th><th> ' . round($asset_total) . ' </th></tr>
<tr><th>Accumulative Expenses</th><td></td></tr>';
        foreach ($acu_expences as $acu_expence) {
            if ($acu_expence->balance > 0)
                echo '<tr><td>' . $acu_expence->coa_title . '</td><td>' . number_format(round($acu_expence->balance)) . '</td></tr>';
            $acu_expence_total += round($acu_expence->balance);
        }

        echo '<tr><th>Accumulative Total</th><th> ' . number_format(round($acu_expence_total)) . ' </th></tr>
<tr><th>Assets Total</th><th> ' . round($asset_total - $acu_expence_total) . ' </th></tr>
<tr><th>Capital Account</th><td></td></tr>';
        foreach ($capitals as $capital) {
            echo '<tr><td>' . $capital->coa_title . '</td><td>' . number_format(round($capital->balance)) . '</td></tr>';
            $capital_total += round($capital->balance);
        }

        echo '<tr><th>Capital Total</th><th> ' . number_format(round($capital_total)) . ' </th></tr>

<tr><th>Net Profit</th><td><b>' . number_format(round($netprofit)) . '</b></td></tr>
<tr><th>liability Account</th><td></td></tr>';
        foreach ($liabilities as $liability) {

            if ($liability->transection_type != '10') {
                if ($liability->balance > 0) {
                    echo '<tr><td>' . $liability->coa_title . '</td><td>' . number_format(round($liability->balance)) . '</td></tr>';
                }
            }
            if ($liability->transection_type == '10') {
                $employee_liability += round($liability->balance);
            }

            $liability_total += round($liability->balance);
        }
        foreach ($assets as $asset) {
            if ($asset->balance < 0) {
                echo '<tr><td>' . $asset->coa_title . '</td><td>' . number_format(round($asset->balance * -1)) . '</td></tr>';
                $liability_total += round($asset->balance * -1);
            }
        }
        echo '<tr><th>Outstanding Wages</th><th> ' . number_format(round($employee_liability)) . ' </th></tr><tr><th>Liability Total</th><th> ' . number_format(round($liability_total)) . ' </th></tr>
<tr><th>Final Total</th><th>' . number_format(round($capital_total + $netprofit + $liability_total)) . '</th></tr>

</table>';
    }

    public function datetodate(Request $request)
    {

        $asset_total           = 0;
        $capital_total         = 0;
        $liability_total       = 0;
        $acu_expence_total     = 0;
        $employee_liability    = 0;
        $customertotal         = 0;
        $liabilitylessthenzero = 0;
        $otherassets           = 0;
        $totalassets           = 0;
        $finaltotal            = 0;
        $totalPayAdvance       = 0;
        $totalCashInHAnd  = 0;
        $sales = 0;
        $query = "";
        $query2 = "";
        $query3 = "";
        $query4 = "";
        $invtotal = 0;
        $queryy = "";
        $incomes = 0;
        $credit_sales = 0;
        $cash_sales = 0;
        $costofsales = 0;
        $expenses = 0;
        $cosquery = "";
        $totalcos = 0;
        $total_income = 0;
        $total_expenses = 0;
        $currentMonth = date('m');
        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=4 && x.account_id !=10101  GROUP BY x.account_id ORDER BY x.account_type ASC');
        $incomes = DB::select($query);

        // $credit_sales=Stichinv::sum('total');
        $salequery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where date(x.date) <= "' . date($request->todate) . '" && x.account_id="10101" ');
        $sales = DB::select($salequery);
        foreach ($sales as $sale) {
            $credit_sales = $sale->balance;
        }
        $cosquery = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date asc) x  where date(x.date) <= "' . date($request->todate) . '" && x.account_id="10102" ');

        $costofsales = DB::select($cosquery);
        foreach ($costofsales as $cos) {
            $totalcos = $cos->balance;
        }

        $query2 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=5 && account_id NOT LIKE "%ade_%" && account_id !="10102"  GROUP BY x.account_id');
        $expenses = DB::select($query2);

        foreach ($expenses as $expense) {
            $total_expenses += $expense->balance;
        }
        $netprofit = $credit_sales - $totalcos - $total_expenses;

        $query = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=1  OR x.account_type=6   GROUP BY account_id ORDER BY x.account_type ASC');
        $assets = DB::select($query);
        $query3 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=3  GROUP BY account_id ORDER BY x.account_type ASC');
        $capitals = DB::select($query3);

        $query4 = DB::raw('SELECT x.*,chartofaccounts.* FROM (SELECT DISTINCT ledgers.balance,ledgers.credit_ammount,ledgers.debit_ammount,ledgers.account_id,ledgers.transection_type,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '" && x.account_type=2  GROUP BY account_id ORDER BY x.account_type ASC');
        $liabilities = DB::select($query4);

        $query2 = DB::raw('SELECT x.balance FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x where date(x.date) <= "' . date($request->todate) . '" && account_id LIKE "%product_%"   ORDER BY x.account_type ASC');
        $inv_total = DB::select($query2);
        foreach ($inv_total as $invto) {
            $invtotal += $invto->balance;
        }
        $queryy = DB::raw('SELECT x.*,chartofaccounts.*,fixedacounts.amo FROM (SELECT DISTINCT ledgers.balance,ledgers.account_id,ledgers.account_type,ledgers.date FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id LEFT JOIN fixedacounts on fixedacounts.ass_name=chartofaccounts.coa_description where date(x.date) <= "' . date($request->todate) . '" && x.account_type=5 && x.account_id LIKE "de_%"  GROUP BY account_id ORDER BY x.account_type ASC');
        $acu_expences = DB::select($queryy);

        foreach ($assets as $asset) {
            if ($asset->balance > 0) {
                if (strpos($asset->account_id, 'customer_') !== false) {
                    $customertotal += $asset->balance;
                } elseif ($asset->account_id == 'padvance101') {
                    $totalPayAdvance  += $asset->balance;
                } elseif ($asset->account_id == 52) {
                    $totalCashInHAnd  += $asset->balance;
                } else {
                    $otherassets += $asset->balance;
                }
                $asset_total += round($asset->balance);
            }
        }
        echo '<h5>To ' . $request->todate . ' Balance Sheet Report</h5><table class="table table-stripped"><tr><td>Customers</td><td>' . number_format(round($customertotal)) . '</td></tr>

      <tr><td>Advance Wages</td><td>' . number_format($totalPayAdvance) . '</td></tr>

      <tr><td>Cash in Hand</td><td>' . number_format($totalCashInHAnd) . '</td></tr>
      <tr><td>Other Assets</td><td>' . number_format(round($otherassets)) . '</td></tr>';

        foreach ($liabilities as $liability) {
            if ($liability->balance < 0) {
                if ($liability->transection_type != 10) {
                    $liabilitylessthenzero += round($liability->balance * -1);
                }
            }
        }
        echo '<tr><td>Other Liabilities</td><td>' . number_format($liabilitylessthenzero) . '</td></tr>
        <tr><td>Sub Assets Total</td><td>' . number_format($asset_total) . ' </td></tr>
        <tr><td>Accumulative Expenses</td><td>  </td></tr>';

        foreach ($acu_expences as $acu_expence) {
            echo '<tr><td>' . $acu_expence->coa_title . '</td><td>' . number_format($acu_expence->balance) . '</td></tr>';
            $acu_expence_total += round($acu_expence->balance);
        }

        echo '.<tr><td>Accumulative Total</td><td>' . $acu_expence_total . ' </td></tr>';
        $totalassets = $asset_total + $liabilitylessthenzero - $acu_expence_total;
        echo '<tr><th>Assets Total</th><th>' . number_format($asset_total + $liabilitylessthenzero - $acu_expence_total) . ' </th></tr><tr><th><br></th><th><br></th></tr><tr><th>Capital Account</th><td>  </td></tr>';
        foreach ($capitals as $capital) {
            echo '<tr><td>' . $capital->coa_title . '</td><td>' . number_format($capital->balance) . '</td></tr>';
            $capital_total += round($capital->balance);
        }
        echo '<tr><th>Net Profit</th><td><b>' . number_format(round($netprofit)) . '</b></td></tr>
    <tr><th><br></th><th><br></th></tr>
    <tr><th>Capital Total</th><th>' . number_format(round($capital_total + $netprofit)) . '</th></tr><tr><th>liability Account</th><td>  </td></tr>';
        foreach ($liabilities as $liability) {
            if ($liability->transection_type != 10) {
                if ($liability->balance > 0) {
                    $liability_total += round($liability->balance);
                }
            }
            if ($liability->transection_type == 10) {
                $employee_liability += round($liability->balance);
            }
        }
        echo '<tr><td>Liability Subtotal</td><td>' . number_format($liability_total) . '</td></tr>';
        foreach ($assets as $asset) {
            if ($asset->balance < 0) {
                $otherassets = 0;
                $asset_total += round($asset->balance * -1);
                $otherassets += round($asset->balance * -1);
                $liability_total += round($asset->balance * -1);
            }
        }
        echo '<tr><td>Other Assets</td><td>' . number_format($otherassets) . '</td></tr>';
        $liability_total = $liability_total + $employee_liability;

        echo '<tr><td>Epmloyee Liability</td><td>' . number_format(round($employee_liability)) . ' </td></tr>
    <tr><th>Liability Total</th><th>' . number_format(round($liability_total)) . ' </th></tr>
    <tr><th><br></th><th><br></th></tr>
    <tr><th>Final Total</th><th>' . number_format(round($capital_total + $netprofit + $liability_total)) . '</th></tr>';
        $finaltotal = $capital_total + $netprofit + $liability_total;
        echo '<tr><th>Rounding Difference</th><th> '.round($finaltotal-$totalassets).'</th></tr>';
        echo '</table>';
    }


    public function trialbalance()
    {
        $query = DB::raw('SELECT x.*,chartofaccounts.coa_title FROM (SELECT DISTINCT ledgers.account_type,ledgers.transection_type,ledgers.date,ledgers.balance,ledgers.account_id FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id GROUP BY account_id ASC ORDER BY account_type ASC,chartofaccounts.coa_title ASC');
        $trialbalance = DB::select($query);
        return view('reports.trialbalance', compact('trialbalance'));
    }
     public function trialBalanceByDate(Request $request)
    {
        if(isset($request->todate)){
        $query = DB::raw('SELECT x.*,chartofaccounts.coa_title FROM (SELECT DISTINCT ledgers.account_type,ledgers.transection_type,ledgers.date,ledgers.balance,ledgers.account_id FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id where date(x.date) <= "' . date($request->todate) . '"  GROUP BY account_id ASC ORDER BY account_type ASC,chartofaccounts.coa_title ASC');
        }
        else{
            $query = DB::raw('SELECT x.*,chartofaccounts.coa_title FROM (SELECT DISTINCT ledgers.account_type,ledgers.transection_type,ledgers.date,ledgers.balance,ledgers.account_id FROM ledgers ORDER BY date DESC) x LEFT JOIN chartofaccounts on chartofaccounts.coa_id=x.account_id GROUP BY account_id ASC ORDER BY account_type ASC,chartofaccounts.coa_title ASC');
        }
        $trialbalance = DB::select($query);
        return view('reports.trialbalancebydate', compact('trialbalance'));
    }
    
    public function machinestitch()
    {
        $query = DB::raw('SELECT machine,sum(stiches.stiches) as stiches,stiches.date FROM `stiches` LEFT JOIN employees on stiches.emp_1 = employees.id WHERE MONTH(stiches.date) =' . date('m') . ' GROUP BY machine');
        $machinestitchs = DB::select($query);
        //return $machinestitchs;
        return view('reports/machinestitch', compact('machinestitchs'));
    }

    public function dailymachinstitches()
    {
        $query = DB::raw('SELECT machine,sum(stiches.stiches) as stiches,stiches.date FROM `stiches` LEFT JOIN employees on stiches.emp_1 = employees.id WHERE stiches.date = CURRENT_DATE GROUP BY machine');
        $machinestitchs = DB::select($query);
        return $machinestitchs;
    }

    public function monthlymachinstitches()
    {
        $query = DB::raw('SELECT machine,sum(stiches.stiches) as stiches,stiches.date FROM `stiches` LEFT JOIN employees on stiches.empid = employees.id WHERE MONTH(stiches.date) =' . date('m') . ' GROUP BY machine');
        $machinestitchs = DB::select($query);
        return $machinestitchs;
    }

    public function Employeestitch()
    {

        $query = DB::raw('SELECT employees.name,sum(stiches.stiches) as stiches,stiches.date FROM `stiches` LEFT JOIN employees on stiches.emp_1 = employees.id WHERE  MONTH(stiches.date) =' . date('m') . ' GROUP  BY emp_1');
        $employeestitchs = DB::select($query);
        return view('reports/Employeestitch', compact('employeestitchs'));
    }

    public function dailyemployeestitches()
    {
        $query = DB::raw('SELECT stiches.emp_1,employees.name,sum(stiches.stiches) as stiches,stiches.date FROM `stiches` LEFT JOIN employees on stiches.emp_1 = employees.id WHERE stiches.date = CURRENT_DATE GROUP  BY emp_1');
        $employeestitchs = DB::select($query);
        return $employeestitchs;
    }

    public function monthlyemployeestitches()
    {
        $query = DB::raw('SELECT stiches.emp_1,employees.name,sum(stiches.stiches) as stiches,stiches.date FROM `stiches` LEFT JOIN employees on stiches.emp_1 = employees.id WHERE  MONTH(stiches.date) =' . date('m') . ' GROUP  BY emp_1');
        $employeestitchs = DB::select($query);
        return $employeestitchs;
    }

    public function ledgercoareport()
    {
        $accounts = Ledger::select('ledgers.*', 'chartofaccounts.coa_title')->leftjoin('chartofaccounts', 'chartofaccounts.coa_id', '=', 'ledgers.account_id')->groupby('ledgers.account_id')->get();
        return view('reports/ledgercoareport', compact('accounts'));
    }

    public function coalegreport(Request $request)
    {
        return Ledger::select('ledgers.*', 'chartofaccounts.coa_title')->leftjoin('chartofaccounts', 'chartofaccounts.coa_id', '=', 'ledgers.account_id')->where('account_id', $request->account)->get();

        // foreach(Ledger::select('ledgers.*','chartofaccounts.coa_title')->leftjoin('chartofaccounts','chartofaccounts.coa_id','=','ledgers.account_id')->where('account_id',$request->account)->get() as $account){
        //    echo "<tr>
        //    <td>".$account->coa_title."</td>
        //     <td>".$account->account_type."</td>
        //     <td>".$account->debit_ammount."</td>
        //     <td>".$account->credit_ammount."</td>
        //     <td>".$account->balance."</td>
        //     <td>".$account->date."</td>
        //    </tr>";
        // }
    }
   
}
